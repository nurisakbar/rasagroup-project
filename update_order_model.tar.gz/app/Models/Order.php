<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory, HasUuids, SoftDeletes;

    const TYPE_REGULAR = 'regular';
    const TYPE_DISTRIBUTOR = 'distributor';
    const TYPE_POS = 'pos';
    const DISTRIBUTOR_POINTS_PER_ITEM = 5000;

    protected $keyType = 'string';
    public $incrementing = false;

    public bool $auto_approved_at_creation = false;

    protected $fillable = [
        'order_number',
        'user_id',
        'order_type',
        'address_id',
        'expedition_id',
        'expedition_service',
        'source_warehouse_id',
        'source_qad_location_code',
        'subtotal',
        'shipping_cost',
        'total_amount',
        'shipping_address',
        'payment_method',
        'company',
        'payment_status',
        'paid_at',
        'order_status',
        'tracking_number',
        'ekspedisiku_shipment_id',
        'ekspedisiku_booking_attempt',
        'ekspedisiku_booking_reference',
        'ekspedisiku_booking_created_at',
        'ekspedisiku_booking_status',
        'ekspedisiku_booking_last_error',
        'ekspedisiku_pickup_requested_at',
        'ekspedisiku_pickup_status',
        'ekspedisiku_pickup_last_error',
        'shipped_at',
        'pickup_ready_at',
        'received_at',
        'pickup_note',
        'notes',
        'points_earned',
        'points_credited',
        'affiliate_id',
        'affiliate_points',
        'discount_percent',
        'discount_amount',
        'preferred_shipping_date',
        'payment_proof',
        'payment_submit_note',
        'payment_submitted_at',
        'finance_approved',
        'finance_approved_at',
        'finance_approved_by',
        'qad_so_number',
        'qid_sales_order_number',
        'jubelio_salesorder_id',
        'jubelio_salesorder_no',
        'sales_code',
        'qad_sync_history',
        'wms_so_status',
        'wms_so_synced_at',
        'wms_so_failure_reason',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'discount_percent' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'points_credited' => 'boolean',
        'paid_at' => 'datetime',
        'shipped_at' => 'datetime',
        'pickup_ready_at' => 'datetime',
        'received_at' => 'datetime',
        'ekspedisiku_booking_created_at' => 'datetime',
        'ekspedisiku_pickup_requested_at' => 'datetime',
        'preferred_shipping_date' => 'date',
        'payment_submitted_at' => 'datetime',
        'finance_approved' => 'boolean',
        'finance_approved_at' => 'datetime',
        'qad_sync_history' => 'array',
    ];

    protected static function booted(): void
    {
        static::saving(function (Order $order) {
            // Pembayaran lunas → otomatis finance approved (1)
            if ($order->isDirty('payment_status') && $order->payment_status === 'paid' && !$order->finance_approved) {
                $order->finance_approved = true;
                if (empty($order->finance_approved_at)) {
                    $order->finance_approved_at = now();
                }
            }
        });

        static::creating(function (Order $order) {
            // Auto approve TOP orders if below credit limit
            if ($order->payment_method === 'term_of_payment' && !$order->finance_approved) {
                $user = $order->user ?? \App\Models\User::find($order->user_id);
                if ($user && $user->credit_limit !== null) {
                    $accumulatedDebt = $user->getAccumulatedTopDebt();
                    if (($accumulatedDebt + (float)$order->total_amount) <= (float)$user->credit_limit) {
                        $order->finance_approved = true;
                        $order->finance_approved_at = now();
                        $order->finance_approved_by = null;
                        $order->payment_status = 'term_of_payment';
                        $order->auto_approved_at_creation = true; // Flag for after-creation notification
                    }
                }
            }
        });

        static::created(function (Order $order) {
            // Notifikasi eksternal otomatis untuk transaksi yang butuh approval finance
            if ($order->isAwaitingFinanceApproval() && config('services.finance_approval.enabled', true)) {
                \App\Jobs\NotifyExternalFinanceApprovalNeeded::dispatch($order);
            }
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function financeApprover(): BelongsTo
    {
        return $this->belongsTo(User::class, 'finance_approved_by');
    }

    public function affiliate(): BelongsTo
    {
        return $this->belongsTo(User::class, 'affiliate_id');
    }

    public function sales(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sales_code', 'sales_code')
                    ->where('role', User::ROLE_SALES ?? 'sales');
    }

    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class)->withTrashed();
    }

    public function expedition(): BelongsTo
    {
        return $this->belongsTo(Expedition::class);
    }

    public function sourceWarehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class, 'source_warehouse_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->order_status) {
            'pending' => 'warning',
            'processing' => 'info',
            'shipped' => 'primary',
            'delivered' => 'success',
            'completed' => 'success',
            'cancelled' => 'danger',
            default => 'default',
        };
    }

    public function getPaymentStatusColorAttribute(): string
    {
        return match ($this->payment_status) {
            'pending' => 'warning',
            'paid' => 'success',
            'failed' => 'danger',
            'refunded' => 'info',
            'term_of_payment' => 'primary',
            default => 'default',
        };
    }

    /**
     * TOP order menunggu persetujuan finance (finance_approved = 0).
     */
    public function isAwaitingFinanceApproval(): bool
    {
        return $this->payment_method === 'term_of_payment' && !$this->finance_approved;
    }

    /**
     * Order sudah boleh diproses hub (finance_approved = 1).
     */
    public function isReleasedToHub(): bool
    {
        return (bool) $this->finance_approved;
    }

    /**
     * Label status approval finance (0 / 1).
     */
    public function financeApprovalLabel(): string
    {
        return $this->finance_approved ? '1' : '0';
    }

    /**
     * Approve finance (set finance_approved = 1) and release order to hub.
     *
     * @return array{success: bool, message: string}
     */
    public function approveFinanceBy(User $approver): array
    {
        if ($this->finance_approved) {
            return [
                'success' => false,
                'message' => 'Transaksi sudah di-approve finance sebelumnya.',
            ];
        }

        $updateData = [
            'finance_approved' => true,
            'finance_approved_at' => now(),
            'finance_approved_by' => $approver->id,
        ];

        // TOP: set payment_status ke term_of_payment saat approve
        if ($this->payment_method === 'term_of_payment' && $this->payment_status === 'pending') {
            $updateData['payment_status'] = 'term_of_payment';
        }

        $this->update($updateData);
        $this->notifyHubAfterFinanceApproval();

        return [
            'success' => true,
            'message' => 'Finance approval berhasil. Transaksi siap diproses hub.',
        ];
    }

    /**
     * Notifikasi hub + sync setelah finance approve.
     */
    public function notifyHubAfterFinanceApproval(): void
    {
        \App\Jobs\SendWhatsAppNotification::dispatch($this, 'warehouse_notification');

        $this->loadMissing('sourceWarehouse.users');

        if ($this->sourceWarehouse) {
            $staffMembers = $this->sourceWarehouse->users;
            if ($staffMembers && $staffMembers->isNotEmpty()) {
                \Illuminate\Support\Facades\Notification::send(
                    $staffMembers,
                    new \App\Notifications\Orders\NewTopOrderNotification($this)
                );
            }
        }

        \App\Support\SalesOrderSyncDispatcher::dispatch($this);
        \App\Jobs\SendSalesOrderToWmsJob::dispatch($this);
    }

    /**
     * Check if order is online (regular order).
     */
    public function isOnline(): bool
    {
        return $this->order_type === self::TYPE_REGULAR;
    }

    /**
     * Check if order is offline (POS order).
     */
    public function isOffline(): bool
    {
        return $this->order_type === self::TYPE_POS;
    }

    /**
     * Order dari hub/website (online) → sinkron ke Jubelio.
     */
    public function shouldSyncToJubelio(): bool
    {
        return $this->order_type === self::TYPE_REGULAR;
    }

    /**
     * Order distributor / POS → sinkron ke QAD.
     */
    public function shouldSyncToQad(): bool
    {
        return in_array($this->order_type, [self::TYPE_DISTRIBUTOR, self::TYPE_POS], true);
    }

    /**
     * Get order type label.
     */
    public function getOrderTypeLabelAttribute(): string
    {
        return match ($this->order_type) {
            self::TYPE_REGULAR => 'Online',
            self::TYPE_POS => 'Offline (POS)',
            self::TYPE_DISTRIBUTOR => 'Distributor',
            default => ucfirst($this->order_type),
        };
    }

    /**
     * Get order type badge class.
     */
    public function getOrderTypeBadgeClassAttribute(): string
    {
        return match ($this->order_type) {
            self::TYPE_REGULAR => 'label-primary',
            self::TYPE_POS => 'label-info',
            self::TYPE_DISTRIBUTOR => 'label-warning',
            default => 'label-default',
        };
    }
    /**
     * Credit earned points to the buyer (DRiiPPreneur) and the affiliate.
     */
    public function creditPoints()
    {
        if ($this->points_credited) {
            return false;
        }

        $credited = false;

        // 1. Credit DRiiPPreneur points (for regular orders)
        if ($this->order_type === self::TYPE_REGULAR && $this->points_earned > 0) {
            $user = $this->user;
            if ($user && $user->isDriippreneurApproved()) {
                $user->increment('points', $this->points_earned);
                $credited = true;
            }
        }

        // 2. Credit Distributor points (for distributor orders)
        if ($this->order_type === self::TYPE_DISTRIBUTOR && $this->points_earned > 0) {
            $user = $this->user;
            if ($user) {
                $user->increment('points', $this->points_earned);
                $credited = true;
            }
        }

        // 3. Credit Affiliate points
        if ($this->affiliate_id && $this->affiliate_points > 0) {
            $affiliate = User::find($this->affiliate_id);
            if ($affiliate) {
                $affiliate->increment('points', $this->affiliate_points);
                $credited = true;
            }
        }

        if ($credited || ($this->points_earned == 0 && $this->affiliate_points == 0)) {
            $this->update(['points_credited' => true]);
            return true;
        }

        return false;
    }
}
