<?php

namespace App\Services;

use App\Models\Address;
use App\Models\Warehouse;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class EkspedisiKuService
{
    protected $token;
    protected $baseUrl;

    public function __construct()
    {
        $this->token = config('services.ekspedisiku.token');
        $this->baseUrl = config('services.ekspedisiku.base_url', 'http://localhost:8001/api');
    }

    /**
     * Get all provinces from local database
     */
    public function getProvinces()
    {
        try {
            $provinces = \App\Models\WilayahAdministratif::select('province_id as id', 'province_name as name')
                ->distinct()
                ->orderBy('province_name')
                ->get();
            return ['success' => true, 'data' => $provinces->toArray()];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getProvinces error', [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            return null;
        }
    }

    /**
     * Get regencies by province ID from local database
     */
    public function getRegencies($provinceId)
    {
        try {
            $regencies = \App\Models\WilayahAdministratif::select('regency_id as id', 'province_id', 'regency_name as name')
                ->where('province_id', $provinceId)
                ->distinct()
                ->orderBy('regency_name')
                ->get();
            return ['success' => true, 'data' => $regencies->toArray()];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getRegencies error', ['province_id' => $provinceId, 'message' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Get districts by regency ID from local database
     */
    public function getDistricts($regencyId)
    {
        try {
            $districts = \App\Models\WilayahAdministratif::select('district_id as id', 'regency_id', 'district_name as name')
                ->where('regency_id', $regencyId)
                ->distinct()
                ->orderBy('district_name')
                ->get();
            return ['success' => true, 'data' => $districts->toArray()];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getDistricts error', ['regency_id' => $regencyId, 'message' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Get villages by district ID from local database
     */
    public function getVillages($districtId)
    {
        try {
            $villages = \App\Models\WilayahAdministratif::select('village_id as id', 'district_id', 'village_name as name')
                ->where('district_id', $districtId)
                ->distinct()
                ->orderBy('village_name')
                ->get();
            return ['success' => true, 'data' => $villages->toArray()];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getVillages error', ['district_id' => $districtId, 'message' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Calculate shipping cost using EkspedisiKu API.
     *
     * Lion Parcel uses GET /ongkir with district IDs.
     * Lalamove uses POST /rates with pickup/dropoff coordinates (pass warehouse + address in $options).
     *
     * @param  array{warehouse?: Warehouse, address?: Address}  $options
     * @return array{data: array<int, array<string, mixed>>}|null
     */
    public function calculateCost($originId, $destinationId, $weight, $courier = 'lion_parcel', array $options = [])
    {
        if ($courier === 'lalamove') {
            return $this->calculateLalamoveCost($options, $weight);
        }

        try {
            $response = Http::timeout(10)->withToken($this->token)
                ->get("{$this->baseUrl}/ongkir", [
                    'origin' => $originId,
                    'destination' => $destinationId,
                    'weight' => $weight,
                    'courier' => $courier,
                ]);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: calculateCost failed', [
                    'origin' => $originId,
                    'destination' => $destinationId,
                    'weight' => $weight,
                    'courier' => $courier,
                    'status' => $response->status(),
                    'response' => $response->json(),
                ]);

                return null;
            }

            $result = $response->json();

            return ['data' => $this->normalizeOngkirRates($result)];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: calculateCost error', [
                'origin' => $originId,
                'destination' => $destinationId,
                'courier' => $courier,
                'message' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * @param  array{warehouse?: Warehouse, address?: Address}  $options
     * @return array{data: array<int, array<string, mixed>>}|null
     */
    protected function calculateLalamoveCost(array $options, $weight): ?array
    {
        $warehouse = $options['warehouse'] ?? null;
        $address = $options['address'] ?? null;

        if (! $warehouse instanceof Warehouse || ! $address instanceof Address) {
            Log::warning('EkspedisiKuService: lalamove requires warehouse and address context');

            return null;
        }

        $resolver = app(ShippingLocationResolver::class);
        $pickup = $resolver->resolvePickup($warehouse);
        $dropoff = $resolver->resolveDropoff($address);

        if ($pickup === null || $dropoff === null) {
            Log::warning('EkspedisiKuService: could not resolve coordinates for lalamove', [
                'warehouse_id' => $warehouse->id,
                'address_id' => $address->id,
                'has_pickup' => $pickup !== null,
                'has_dropoff' => $dropoff !== null,
            ]);

            return null;
        }

        try {
            $types = ['MOTORCYCLE', 'MPV'];
            $responses = \Illuminate\Support\Facades\Http::pool(fn (\Illuminate\Http\Client\Pool $pool) => collect($types)->map(fn ($type) => 
                $pool->as($type)->timeout(10)->withToken($this->token)->acceptJson()->post("{$this->baseUrl}/rates", [
                    'pickup' => $pickup,
                    'dropoff' => $dropoff,
                    'weight' => max(1, (float) $weight),
                    'service_type' => $type
                ])
            ));

            $normalizedData = [];
            
            foreach ($responses as $type => $response) {
                if ($response instanceof \Exception || $response->failed()) {
                    Log::warning("EkspedisiKuService: lalamove rates failed for {$type}");
                    continue;
                }
                
                $result = $response->json();
                $carrier = collect($result['carriers'] ?? [])->firstWhere('id', 'lalamove');

                if (! is_array($carrier) || (int) ($carrier['status'] ?? 0) !== 200) {
                    continue;
                }

                foreach ($carrier['services'] ?? [] as $service) {
                    if (! is_array($service)) {
                        continue;
                    }

                    $normalizedData[] = [
                        'code' => 'lalamove',
                        'name' => (string) ($carrier['label'] ?? 'Lalamove'),
                        'service' => (string) ($service['code'] ?? $type),
                        'description' => (string) ($service['name'] ?? $type),
                        'cost' => $service['price'] ?? 0,
                        'etd' => $service['etd'] ?? null,
                        'quotation_id' => $service['quotation_id'] ?? null,
                    ];
                }
            }

            if (empty($normalizedData)) {
                Log::warning('EkspedisiKuService: lalamove totally unavailable for all types', [
                    'pickup' => $pickup,
                    'dropoff' => $dropoff,
                ]);
            }

            return ['data' => $normalizedData];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: lalamove calculateCost error', [
                'warehouse_id' => $warehouse->id,
                'address_id' => $address->id,
                'message' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    protected function normalizeOngkirRates(array $result): array
    {
        $normalizedData = [];

        if (isset($result['rates']) && isset($result['rates']['services'])) {
            $carrier = $result['rates'];
            foreach ($carrier['services'] as $service) {
                $normalizedData[] = [
                    'code' => $carrier['id'],
                    'name' => $carrier['label'],
                    'service' => $service['code'],
                    'description' => $service['name'],
                    'cost' => $service['price'],
                    'etd' => $service['etd'],
                ];
            }
        }

        return $normalizedData;
    }

    /**
     * Create a shipment booking
     * 
     * @param array $payload
     * @return array|null
     */
    public function createBooking(array $payload)
    {
        try {
            Log::debug('EkspedisiKuService: createBooking request', [
                'url' => "{$this->baseUrl}/shipments",
                'carrier' => $payload['carrier'] ?? null,
                'reference' => $payload['shipment']['reference'] ?? null,
                'service_code' => $payload['shipment']['package']['service_code'] ?? null,
                'origin' => $payload['shipment']['origin'] ?? null,
                'destination' => $payload['shipment']['destination'] ?? null,
            ]);

            $response = Http::timeout(10)->withToken($this->token)
                ->post("{$this->baseUrl}/shipments", $payload);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: createBooking failed', [
                    'status' => $response->status(),
                    'response' => $response->json(),
                    'body' => $response->body(),
                ]);
                // Return the response body so caller can surface the error
                return $response->json() ?? [
                    'success' => false,
                    'message' => 'Create booking failed',
                    'error' => [
                        'status' => $response->status(),
                        'body' => $response->body(),
                    ],
                ];
            }

            $json = $response->json();
            Log::debug('EkspedisiKuService: createBooking success', [
                'status' => $response->status(),
                'result_keys' => is_array($json) ? array_keys($json) : null,
                'success' => is_array($json) ? ($json['success'] ?? null) : null,
                'message' => is_array($json) ? ($json['message'] ?? null) : null,
                'data_keys' => (is_array($json) && is_array($json['data'] ?? null)) ? array_keys($json['data']) : null,
                'data' => (is_array($json) && is_array($json['data'] ?? null)) ? $json['data'] : null,
            ]);

            return $json;
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: createBooking error', [
                'message' => $e->getMessage(),
                // Avoid logging full payload here (already logged in job); keep it small.
                'carrier' => $payload['carrier'] ?? null,
                'reference' => $payload['shipment']['reference'] ?? null,
            ]);
            return null;
        }
    }

    public function getShipment(string|int $shipmentId): ?array
    {
        try {
            $url = "{$this->baseUrl}/shipments/{$shipmentId}";
            Log::debug('EkspedisiKuService: getShipment request', [
                'url' => $url,
                'shipment_id' => (string) $shipmentId,
            ]);

            $response = Http::timeout(10)->withToken($this->token)->get($url);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: getShipment failed', [
                    'shipment_id' => (string) $shipmentId,
                    'status' => $response->status(),
                    'response' => $response->json(),
                    'body' => $response->body(),
                ]);
                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getShipment error', [
                'shipment_id' => (string) $shipmentId,
                'message' => $e->getMessage(),
            ]);
            return null;
        }
    }

    /**
     * Track a shipment
     * 
     * @param string $resi
     * @param string $carrier
     * @return array|null
     */
    public function track($resi, $carrier)
    {
        try {
            $response = Http::timeout(10)->withToken($this->token)
                ->get("{$this->baseUrl}/track/{$resi}", [
                    'carrier' => $carrier
                ]);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: track failed', [
                    'resi' => $resi,
                    'carrier' => $carrier,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
                return null;
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: track error', [
                'resi' => $resi,
                'message' => $e->getMessage()
            ]);
            return null;
        }
    }

    /**
     * Trace request pickup: endpoint, payload, status HTTP, body (tanpa mengubah order).
     *
     * @param  bool  $executeRequest  false = hanya tampilkan endpoint + payload
     * @return array<string, mixed>
     */
    public function requestPickupDebug(array $shipmentIds, $startAt, $endAt, bool $executeRequest = true): array
    {
        $endpoint = rtrim((string) $this->baseUrl, '/') . '/pickup';
        $payload = [
            'pickup' => [
                'shipment_ids' => $shipmentIds,
                'start_at' => $startAt,
                'end_at' => $endAt,
            ],
        ];

        $base = [
            'ok' => true,
            'endpoint' => $endpoint,
            'method' => 'POST',
            'headers_note' => 'Authorization: Bearer <token>, Timezone: +07:00',
            'payload' => $payload,
        ];

        if (! $executeRequest) {
            return $base + [
                'dry_run' => true,
                'http_status' => null,
                'response' => null,
                'response_raw' => null,
                'note' => 'Dry run: tidak ada HTTP POST ke EkspedisiKu.',
            ];
        }

        try {
            Log::info('EkspedisiKuService: Requesting pickup (debug)', [
                'url' => $endpoint,
                'payload' => $payload,
            ]);

            $response = Http::timeout(10)->withToken($this->token)
                ->withHeaders([
                    'Timezone' => '+07:00',
                ])
                ->post($endpoint, $payload);

            Log::info('EkspedisiKuService: Pickup response (debug)', [
                'status' => $response->status(),
                'response' => $response->json(),
            ]);

            return $base + [
                'dry_run' => false,
                'http_status' => $response->status(),
                'response' => $response->json(),
                'response_raw' => $response->body(),
            ];
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: requestPickupDebug error', [
                'message' => $e->getMessage(),
            ]);

            return $base + [
                'ok' => false,
                'dry_run' => false,
                'error' => $e->getMessage(),
                'http_status' => null,
                'response' => null,
                'response_raw' => null,
            ];
        }
    }

    /**
     * Request pickup
     *
     * @param array $shipmentIds
     * @param string $startAt
     * @param string $endAt
     * @return array|null
     */
    public function requestPickup(array $shipmentIds, $startAt, $endAt)
    {
        try {
            $payload = [
                'pickup' => [
                    'shipment_ids' => $shipmentIds,
                    'start_at' => $startAt,
                    'end_at' => $endAt
                ]
            ];

            Log::info('EkspedisiKuService: Requesting pickup', [
                'url' => "{$this->baseUrl}/pickup",
                'payload' => $payload
            ]);

            $response = Http::timeout(10)->withToken($this->token)
                ->withHeaders([
                    'Timezone' => '+07:00'
                ])
                ->post("{$this->baseUrl}/pickup", $payload);

            Log::info('EkspedisiKuService: Pickup response', [
                'status' => $response->status(),
                'response' => $response->json()
            ]);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: requestPickup failed', [
                    'shipment_ids' => $shipmentIds,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
                return $response->json(); // Return json even if failed to get error message
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: requestPickup error', [
                'message' => $e->getMessage()
            ]);
            return null;
        }
    }

    /**
     * Cancel a pickup request (Lion Parcel).
     *
     * @param string $shipmentId Lion shipment id (stt_id)
     * @return array|null
     */
    public function cancelPickup(string $shipmentId)
    {
        try {
            $payload = [
                'shipment_id' => $shipmentId,
            ];

            Log::info('EkspedisiKuService: Cancelling pickup', [
                'url' => "{$this->baseUrl}/pickup/cancel",
                'payload' => $payload,
            ]);

            $response = Http::timeout(10)->withToken($this->token)
                ->post("{$this->baseUrl}/pickup/cancel", $payload);

            Log::info('EkspedisiKuService: Cancel pickup response', [
                'status' => $response->status(),
                'response' => $response->json(),
            ]);

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: cancelPickup failed', [
                    'shipment_id' => $shipmentId,
                    'status' => $response->status(),
                    'response' => $response->json(),
                ]);

                return $response->json();
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: cancelPickup error', [
                'shipment_id' => $shipmentId,
                'message' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Get list of available couriers
     */
    public function getCouriers()
    {
        $cached = \Illuminate\Support\Facades\Cache::get('ekspedisiku_couriers');
        if ($cached) {
            return $cached;
        }

        try {
            $response = Http::timeout(10)->withToken($this->token)
                ->get("{$this->baseUrl}/couriers");

            if ($response->failed()) {
                Log::warning('EkspedisiKuService: getCouriers failed', [
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
                return null;
            }

            $data = $response->json();
            if ($data) {
                \Illuminate\Support\Facades\Cache::put('ekspedisiku_couriers', $data, now()->addMinutes(60));
            }
            return $data;
        } catch (\Exception $e) {
            Log::error('EkspedisiKuService: getCouriers error', ['message' => $e->getMessage()]);
            return null;
        }
    }
}
