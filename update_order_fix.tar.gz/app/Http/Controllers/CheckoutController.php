<?php

namespace App\Http\Controllers;

use App\Models\Address;
use App\Models\Cart;
use App\Models\Expedition;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use App\Models\Warehouse;
use App\Models\WarehouseStock;
use App\Jobs\ProcessCheckoutSuccessJob;
use App\Services\FaspayService;
use App\Support\QadWsOrderNumberGenerator;
use App\Support\ShopFulfillment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;

class CheckoutController extends Controller
{
    protected $ekspedisiku;

    public function __construct(\App\Services\EkspedisiKuService $ekspedisiku)
    {
        $this->ekspedisiku = $ekspedisiku;
    }

    public function index()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu.');
        }

        Auth::user()->loadMissing('priceLevel');

        $query = Cart::with(['product', 'warehouse.wilayah'])
            ->where('user_id', Auth::id())
            ->where('cart_type', 'regular');

        if (request()->has('cart_ids') && is_array(request('cart_ids'))) {
            $query->whereIn('id', request('cart_ids'));
        }

        $carts = $query->get();

        if ($carts->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Keranjang kosong.');
        }

        // Get the source warehouse from cart (all items should be from same warehouse)
        $sourceWarehouse = $carts->first()->warehouse;
        
        // Verify all items are from same warehouse
        $differentWarehouse = $carts->first(function ($cart) use ($sourceWarehouse) {
            return $cart->warehouse_id !== $sourceWarehouse?->id;
        });
        
        if ($differentWarehouse) {
            return redirect()->route('cart.index')
                ->with('error', 'Keranjang memiliki produk dari hub yang berbeda. Silakan kosongkan keranjang dan pilih produk dari hub yang sama.');
        }

        if (!$sourceWarehouse) {
            return redirect()->route('cart.index')
                ->with('error', 'Hub pengirim tidak ditemukan. Silakan tambahkan produk ke keranjang kembali.');
        }

        // Check if warehouse has complete location data
        if (!$sourceWarehouse->district_id) {
            return redirect()->route('cart.index')
                ->with('error', 'Data lokasi hub pengirim belum lengkap. Silakan hubungi administrator untuk melengkapi data lokasi hub (Provinsi, Kota, dan Kecamatan).');
        }

        // Only show expeditions that are active in DB AND active in EkspedisiKu API
        $apiCourierCodes = $this->activeApiCourierCodes();

        $expeditions = Expedition::where('is_active', true)
            ->whereIn('code', $apiCourierCodes)
            ->get();
        $defaultExpedition = $expeditions->firstWhere('code', 'lion_parcel') ?? $expeditions->first();

        $addresses = Auth::user()->addresses()
            ->with(['wilayah'])
            ->orderByDesc('is_default')
            ->get();

        if ($addresses->isEmpty()) {
            session(['checkout_return_after_address' => true]);

            return redirect()->route('buyer.addresses.create', ['origin' => 'checkout'])
                ->with('info', 'Tambahkan alamat pengiriman terlebih dahulu untuk melanjutkan checkout.');
        }

        $defaultAddress = $addresses->where('id', request('address_id'))->first()
            ?? $addresses->firstWhere('is_default', true) 
            ?? $addresses->first();

        $stockWarnings = [];
        // Re-detect best Hub based on default address
        if ($defaultAddress) {
            $syncResult = $this->syncWarehouseByAddress($defaultAddress);
            if ($syncResult && $syncResult['hub_changed']) {
                $sourceWarehouse = $syncResult['warehouse'];
                // Refresh carts
                $carts = Cart::with(['product', 'warehouse.wilayah'])
                    ->where('user_id', Auth::id())
                    ->where('cart_type', 'regular')
                    ->get();
            }
            if ($syncResult && isset($syncResult['stock_warnings'])) {
                $stockWarnings = $syncResult['stock_warnings'];
            }
        }

        $totalWeight = $carts->sum(function ($cart) {
            return ($cart->product->weight ?? 500) * $cart->quantity;
        });

        $pricing = $this->cartPricingBreakdown(Auth::user(), $carts);
        $retailSubtotal = $pricing['retail_subtotal'];
        $distributorPriceDiscount = $pricing['distributor_price_discount'];
        $tieredDiscountAmount = $pricing['tiered_discount_amount'];
        $tieredDiscountDetails = $pricing['tiered_discount_details'];
        $showTieredDiscount = $pricing['show_tiered_discount'];
        $subtotal = $pricing['subtotal_after_distributor'];
        $priceLevelName = $pricing['price_level_name'];
        $showDistributorPricing = $pricing['show_distributor_pricing'];

        // Check if default address has district_id
        if ($defaultAddress && !$defaultAddress->district_id) {
            return redirect()->route('buyer.addresses.index')
                ->with('error', 'Alamat pengiriman belum memiliki data kecamatan. Silakan lengkapi data alamat Anda terlebih dahulu.');
        }
    
    // Calculate shipping cost based on default address and expedition
    $shippingCost = 0;
    $allShippingServices = [];
    $defaultService = null;

    // Debug logging
    /*
    \Log::info('=== CHECKOUT DEBUG ===');
    \Log::info('Source Warehouse:', [
        'id' => $sourceWarehouse->id,
        'name' => $sourceWarehouse->name,
        'district_id' => $sourceWarehouse->district_id,
        'province_id' => $sourceWarehouse->province_id,
        'regency_id' => $sourceWarehouse->regency_id,
    ]);
    
    if ($defaultAddress) {
        \Log::info('Default Address:', [
            'id' => $defaultAddress->id,
            'recipient' => $defaultAddress->recipient_name,
            'district_id' => $defaultAddress->district_id,
            'province_id' => $defaultAddress->province_id,
            'regency_id' => $defaultAddress->regency_id,
        ]);
    } else {
        \Log::warning('No default address found');
    }
    
    \Log::info('Total Weight:', ['weight' => $totalWeight]);
    \Log::info('Expeditions:', ['count' => $expeditions->count(), 'codes' => $expeditions->pluck('code')->toArray()]);
    */

    if ($defaultAddress && $sourceWarehouse && $sourceWarehouse->district_id && $expeditions->count() > 0) {
        $courierCodes = $expeditions->pluck('code')->implode(':');
        
        \Log::info('Calling Shipping Service API:', [
            'origin' => $sourceWarehouse->district_id,
            'destination' => $defaultAddress->district_id,
            'weight' => $totalWeight,
            'courier' => $defaultExpedition->code,
        ]);
        
        $costResult = $this->resolveShippingCost(
            $defaultExpedition,
            $sourceWarehouse,
            $defaultAddress,
            $totalWeight
        );

        \Log::info('Shipping Response:', [
            'courier' => $defaultExpedition->code,
            'has_data' => isset($costResult['data']),
            'data_count' => isset($costResult['data']) ? count($costResult['data']) : 0,
            'full_response' => $costResult,
        ]);

        if ($costResult && isset($costResult['data']) && !empty($costResult['data'])) {
            // RajaOngkir returns flat array of services, filter by first expedition code
            $firstExpCode = $defaultExpedition->code;
            \Log::info('Looking for services for expedition:', ['code' => $firstExpCode]);
            
            $matchCount = 0;
            foreach ($costResult['data'] as $service) {
                \Log::info('Checking service:', [
                    'code' => $service['code'],
                    'name' => $service['name'] ?? 'N/A',
                    'service' => $service['service'] ?? 'N/A',
                    'cost' => $service['cost'] ?? 'N/A',
                ]);
                
                // Match by courier code
                if ($service['code'] === $firstExpCode) {
                    \Log::info('Found matching service for expedition');
                    
                    $originalCost = $service['cost'];
                    $cost = $originalCost;
                    $isDiscounted = false;
                    
                    if ($firstExpCode === 'jne') {
                        $weightKg = max(1, ceil($totalWeight / 1000));
                        $isDiscounted = true;
                        $originalCost = $originalCost * $weightKg;
                        $cost = $originalCost * 0.8;
                    }

                    $item = [
                        'code' => $service['service'],
                        'name' => $service['description'],
                        'cost' => $cost,
                        'original_cost' => $originalCost,
                        'is_discounted' => $isDiscounted,
                        'cost_formatted' => 'Rp ' . number_format($cost, 0, ',', '.'),
                        'original_cost_formatted' => 'Rp ' . number_format($originalCost, 0, ',', '.'),
                        'estimated_days' => $this->formatEstimatedDelivery($service['etd'] ?? null, $firstExpCode)
                    ];
                    $allShippingServices[] = $item;
                    
                    \Log::info('Added service:', $item);
                    
                    // Set first matching service as default
                    if ($matchCount === 0) {
                        $defaultService = $item;
                        $shippingCost = $item['cost'];
                        \Log::info('Set as default service');
                    }
                    $matchCount++;
                }
            }
            
            \Log::info('Total services found:', ['count' => count($allShippingServices)]);
        } else {
            \Log::warning('No cost data returned from RajaOngkir');
        }
    } else {
        \Log::warning('Skipping shipping calculation:', [
            'has_address' => (bool)$defaultAddress,
            'has_warehouse' => (bool)$sourceWarehouse,
            'warehouse_has_district' => $sourceWarehouse ? (bool)$sourceWarehouse->district_id : false,
            'expeditions_count' => $expeditions->count(),
        ]);
    }

    // \Log::info('=== END CHECKOUT DEBUG ===');
    
    // Disable old DiscountTier logic as per new category-based discount rule
    $discountAmount = 0;
    $discountPercent = 0;

    $total = $subtotal - $discountAmount + $shippingCost;

    // Track affiliate
    $affiliate = null;
    $affiliateId = session('affiliate_id');
    if ($affiliateId && $affiliateId !== Auth::id()) {
        $affiliate = User::find($affiliateId);
    }

    $cart_ids = request('cart_ids', []);

    $originalShippingCost = $shippingCost;
    $isShippingDiscounted = false;
    if ($defaultExpedition && $defaultExpedition->code === 'jne' && $shippingCost > 0) {
        $isShippingDiscounted = true;
        $originalShippingCost = $shippingCost / 0.8;
    }
    
    $paymentFees = [
        'faspay_bca_va' => (float) \App\Models\Setting::get('fee_faspay_bca_va', 0),
        'faspay_mandiri_va' => (float) \App\Models\Setting::get('fee_faspay_mandiri_va', 0),
        'faspay_bri_va' => (float) \App\Models\Setting::get('fee_faspay_bri_va', 0),
        'faspay_bni_va' => (float) \App\Models\Setting::get('fee_faspay_bni_va', 0),
        'faspay_cimb_va' => (float) \App\Models\Setting::get('fee_faspay_cimb_va', 0),
        'faspay_permata_va' => (float) \App\Models\Setting::get('fee_faspay_permata_va', 0),
        'faspay_sinarmas_va' => (float) \App\Models\Setting::get('fee_faspay_sinarmas_va', 0),
        'faspay_maybank_va' => (float) \App\Models\Setting::get('fee_faspay_maybank_va', 0),
        'faspay_danamon_va' => (float) \App\Models\Setting::get('fee_faspay_danamon_va', 0),
        'faspay_bsi_va' => (float) \App\Models\Setting::get('fee_faspay_bsi_va', 0),
        'faspay_qris' => (float) \App\Models\Setting::get('fee_faspay_qris', 0),
    ];

    return view('checkout.index', compact(
        'carts', 
        'subtotal', 
        'retailSubtotal',
        'distributorPriceDiscount',
        'tieredDiscountAmount',
        'tieredDiscountDetails',
        'showTieredDiscount',
        'priceLevelName',
        'showDistributorPricing',
        'shippingCost', 
        'originalShippingCost',
        'isShippingDiscounted',
        'discountAmount',
        'discountPercent',
        'total', 
        'addresses', 
        'defaultAddress',
        'totalWeight',
        'expeditions',
        'defaultExpedition',
        'defaultService',
        'allShippingServices',
        'sourceWarehouse',
        'affiliate',
        'cart_ids',
        'paymentFees',
        'stockWarnings'
    ));
}

    public function calculateShipping(Request $request)
    {
        $address = Address::with(['wilayah'])->find($request->address_id);
        
        if (!$address || $address->user_id !== Auth::id()) {
            return response()->json(['error' => 'Alamat tidak valid'], 400);
        }

        $carts = Cart::with(['product', 'warehouse.wilayah'])
            ->where('user_id', Auth::id())
            ->where('cart_type', 'regular')
            ->get();

        // Re-detect best Hub based on selected address
        $syncResult = $this->syncWarehouseByAddress($address) ?? [];
        if (!empty($syncResult['hub_changed'])) {
            $carts = Cart::with(['product', 'warehouse.wilayah'])
                ->where('user_id', Auth::id())
                ->where('cart_type', 'regular')
                ->get();
        }

        $totalWeight = $carts->sum(function ($cart) {
            return ($cart->product->weight ?? 500) * $cart->quantity;
        });

        Auth::user()->loadMissing('priceLevel');
        $pricing = $this->cartPricingBreakdown(Auth::user(), $carts);
        $retailSubtotal = $pricing['retail_subtotal'];
        $distributorPriceDiscount = $pricing['distributor_price_discount'];
        $subtotal = $pricing['subtotal_after_distributor'];
        $showDistributorPricing = $pricing['show_distributor_pricing'];
        $priceLevelName = $pricing['price_level_name'];

        $sourceWarehouse = $syncResult['warehouse'] ?? $carts->first()?->warehouse;
        $hubChanged = $syncResult['hub_changed'] ?? false;
        $stockWarnings = $syncResult['stock_warnings'] ?? [];

        if (!$sourceWarehouse || !$sourceWarehouse->district_id) {
            return response()->json(['error' => 'Data hub pengirim tidak lengkap'], 400);
        }

        $expedition = $this->findAvailableExpedition($request->expedition_id);
        if (!$expedition) {
            return response()->json(['error' => 'Ekspedisi tidak ditemukan atau tidak tersedia'], 400);
        }

        $costResult = $this->resolveShippingCost(
            $expedition,
            $sourceWarehouse,
            $address,
            $totalWeight
        );

        $shippingCost = 0;
        $serviceName = $request->service_code;
        $estimatedDelivery = '-';

        // \Log::info('=== CALCULATE SHIPPING DEBUG ===');
        \Log::info('Request params:', [
            'expedition_id' => $request->expedition_id,
            'expedition_code' => $expedition->code,
            'service_code' => $request->service_code,
        ]);
        \Log::info('Shipping response:', [
            'expedition' => $expedition->code,
            'has_data' => isset($costResult['data']),
            'data_count' => isset($costResult['data']) ? count($costResult['data']) : 0,
            'data' => $costResult['data'] ?? [],
        ]);

        if ($costResult && isset($costResult['data']) && !empty($costResult['data'])) {
            // RajaOngkir returns flat array, find matching service
            foreach ($costResult['data'] as $service) {
                \Log::info('Checking service:', [
                    'service_code' => $service['service'] ?? null,
                    'service_name' => $service['description'] ?? null,
                    'matches_expedition' => ($service['code'] ?? '') === $expedition->code,
                    'matches_service' => ($service['service'] ?? '') === $request->service_code,
                ]);
                
                if (($service['code'] ?? '') === $expedition->code && ($service['service'] ?? '') === $request->service_code) {
                    $originalShippingCost = $service['cost'];
                    $shippingCost = $originalShippingCost;
                    
                    if ($expedition->code === 'jne') {
                        $weightKg = max(1, ceil($totalWeight / 1000));
                        $originalShippingCost = $originalShippingCost * $weightKg;
                        $shippingCost = $originalShippingCost * 0.8;
                    }

                    $serviceName = $service['description'];
                    $estimatedDelivery = $this->formatEstimatedDelivery($service['etd'] ?? null, $expedition->code);
                    \Log::info('MATCH FOUND!', [
                        'cost' => $shippingCost,
                        'original_cost' => $originalShippingCost,
                        'name' => $serviceName,
                        'etd' => $estimatedDelivery,
                    ]);
                    break;
                }
            }
        }

        // No fallback for shipping cost anymore, we want real API data
        
        \Log::info('Final shipping cost:', ['cost' => $shippingCost]);

        // Calculate discount
        $totalQuantity = $carts->sum('quantity');
        $applicableDiscount = \App\Models\DiscountTier::getApplicableDiscount($totalQuantity);
        $discountAmount = 0;
        $discountPercent = 0;
        if ($applicableDiscount) {
            $discountAmount = ($subtotal * $applicableDiscount->discount_percent) / 100;
            $discountPercent = $applicableDiscount->discount_percent;
        }

        $total = $subtotal - $discountAmount + $shippingCost;

        $isShippingDiscounted = false;
        $originalShippingCost = $shippingCost;
        if ($expedition->code === 'jne') {
            $isShippingDiscounted = true;
            $originalShippingCost = $shippingCost / 0.8;
        }
        
        $paymentFees = [
            'faspay_bca_va' => (float) \App\Models\Setting::get('fee_faspay_bca_va', 0),
            'faspay_mandiri_va' => (float) \App\Models\Setting::get('fee_faspay_mandiri_va', 0),
            'faspay_bri_va' => (float) \App\Models\Setting::get('fee_faspay_bri_va', 0),
            'faspay_bni_va' => (float) \App\Models\Setting::get('fee_faspay_bni_va', 0),
            'faspay_cimb_va' => (float) \App\Models\Setting::get('fee_faspay_cimb_va', 0),
            'faspay_permata_va' => (float) \App\Models\Setting::get('fee_faspay_permata_va', 0),
            'faspay_sinarmas_va' => (float) \App\Models\Setting::get('fee_faspay_sinarmas_va', 0),
            'faspay_maybank_va' => (float) \App\Models\Setting::get('fee_faspay_maybank_va', 0),
            'faspay_danamon_va' => (float) \App\Models\Setting::get('fee_faspay_danamon_va', 0),
            'faspay_bsi_va' => (float) \App\Models\Setting::get('fee_faspay_bsi_va', 0),
            'faspay_qris' => (float) \App\Models\Setting::get('fee_faspay_qris', 0),
        ];

        return response()->json([
            'payment_fees' => $paymentFees,
            'total_weight' => $totalWeight,
            'shipping_cost' => $shippingCost,
            'original_shipping_cost' => $originalShippingCost,
            'shipping_cost_formatted' => 'Rp ' . number_format($shippingCost, 0, ',', '.'),
            'original_shipping_cost_formatted' => 'Rp ' . number_format($originalShippingCost, 0, ',', '.'),
            'is_shipping_discounted' => $isShippingDiscounted,
            'subtotal' => $subtotal,
            'subtotal_formatted' => 'Rp ' . number_format($subtotal, 0, ',', '.'),
            'retail_subtotal' => $retailSubtotal,
            'retail_subtotal_formatted' => 'Rp ' . number_format($retailSubtotal, 0, ',', '.'),
            'distributor_price_discount' => $distributorPriceDiscount,
            'distributor_price_discount_formatted' => 'Rp ' . number_format($distributorPriceDiscount, 0, ',', '.'),
            'show_distributor_pricing' => $showDistributorPricing,
            'tiered_discount_amount' => $pricing['tiered_discount_amount'] ?? 0,
            'tiered_discount_amount_formatted' => 'Rp ' . number_format($pricing['tiered_discount_amount'] ?? 0, 0, ',', '.'),
            'show_tiered_discount' => $pricing['show_tiered_discount'] ?? false,
            'price_level_name' => $priceLevelName,
            'discount_amount' => $discountAmount,
            'discount_amount_formatted' => 'Rp ' . number_format($discountAmount, 0, ',', '.'),
            'discount_percent' => $discountPercent,
            'total' => $total,
            'total_formatted' => 'Rp ' . number_format($total, 0, ',', '.'),
            'total_weight' => $totalWeight,
            'total_weight_formatted' => number_format($totalWeight / 1000, 1) . ' kg',
            'service_name' => $serviceName,
            'estimated_delivery' => $estimatedDelivery,
            'hub_changed' => $hubChanged,
            'stock_warnings' => $stockWarnings,
            'address' => [
                'id' => $address->id,
                'recipient_name' => $address->recipient_name,
                'phone' => $address->phone,
                'full_address' => $address->full_address,
            ],
            'warehouse' => $sourceWarehouse ? [
                'id' => $sourceWarehouse->id,
                'name' => $sourceWarehouse->name,
                'location' => $sourceWarehouse->full_location,
            ] : null,
        ]);
    }

    public function getExpeditionServices(Request $request)
    {
        Log::debug('[checkout.expedition-services] request', [
            'user_id' => Auth::id(),
            'expedition_id' => $request->expedition_id,
            'address_id' => $request->address_id,
            'query' => $request->query(),
        ]);

        $expedition = $this->findAvailableExpedition($request->expedition_id);

        if (!$expedition) {
            Log::debug('[checkout.expedition-services] expedition not found', [
                'expedition_id' => $request->expedition_id,
                'active_api_couriers' => $this->activeApiCourierCodes(),
            ]);

            return response()->json(['error' => 'Ekspedisi tidak valid atau tidak tersedia'], 400);
        }

        $address = Address::with(['wilayah'])->find($request->address_id);
        if (!$address) {
            Log::debug('[checkout.expedition-services] address not found', [
                'address_id' => $request->address_id,
            ]);

            return response()->json(['error' => 'Alamat tidak ditemukan'], 400);
        }

        $carts = Cart::with(['product', 'warehouse.wilayah'])
            ->where('user_id', Auth::id())
            ->where('cart_type', 'regular')
            ->get();
        
        $totalWeight = $carts->sum(function ($cart) {
            return ($cart->product->weight ?? 500) * $cart->quantity;
        });

        // Re-detect best Hub based on selected address
        $syncResult = $this->syncWarehouseByAddress($address);
        $sourceWarehouse = $syncResult['warehouse'] ?? $carts->first()?->warehouse;

        Log::debug('[checkout.expedition-services] context', [
            'expedition' => [
                'id' => $expedition->id,
                'code' => $expedition->code,
                'name' => $expedition->name,
            ],
            'address' => [
                'id' => $address->id,
                'district_id' => $address->district_id,
                'regency_id' => $address->regency_id,
                'province_id' => $address->province_id,
                'district' => $address->district?->name,
                'regency' => $address->regency?->name,
            ],
            'warehouse' => $sourceWarehouse ? [
                'id' => $sourceWarehouse->id,
                'name' => $sourceWarehouse->name,
                'district_id' => $sourceWarehouse->district_id,
                'regency_id' => $sourceWarehouse->regency_id,
                'province_id' => $sourceWarehouse->province_id,
            ] : null,
            'total_weight_grams' => $totalWeight,
            'total_weight_kg' => round($totalWeight / 1000, 3),
            'cart_items' => $carts->count(),
            'uses_ekspedisiku' => $this->usesEkspedisiKuRates($expedition->code),
        ]);

        if (!$sourceWarehouse || !$sourceWarehouse->district_id) {
            Log::debug('[checkout.expedition-services] warehouse incomplete', [
                'warehouse_id' => $sourceWarehouse?->id,
                'district_id' => $sourceWarehouse?->district_id,
            ]);

             return response()->json(['error' => 'Data hub pengirim tidak lengkap'], 400);
        }
        
        $costResult = $this->resolveShippingCost(
            $expedition,
            $sourceWarehouse,
            $address,
            $totalWeight
        );

        $services = [];
        if ($costResult && isset($costResult['data']) && !empty($costResult['data'])) {
            // RajaOngkir returns flat array, filter by expedition code
            foreach ($costResult['data'] as $service) {
                Log::debug('[checkout.expedition-services] checking service row', [
                    'service_code' => $service['code'] ?? null,
                    'service' => $service['service'] ?? null,
                    'description' => $service['description'] ?? null,
                    'cost' => $service['cost'] ?? null,
                    'matches_expedition' => ($service['code'] ?? '') === $expedition->code,
                ]);

                if (($service['code'] ?? '') === $expedition->code) {
                    $originalCost = $service['cost'];
                    $cost = $originalCost;
                    $isDiscounted = false;

                    if ($expedition->code === 'jne') {
                        $isDiscounted = true;
                        $cost = $originalCost * 0.8;
                    }

                    $services[] = [
                        'code' => $service['service'],
                        'name' => $service['description'],
                        'cost' => $cost,
                        'original_cost' => $originalCost,
                        'is_discounted' => $isDiscounted,
                        'cost_formatted' => 'Rp ' . number_format($cost, 0, ',', '.'),
                        'original_cost_formatted' => 'Rp ' . number_format($originalCost, 0, ',', '.'),
                        'estimated_days' => $this->formatEstimatedDelivery($service['etd'] ?? null, $expedition->code),
                    ];
                }
            }
        }

        $responsePayload = [
            'expedition' => [
                'id' => $expedition->id,
                'code' => $expedition->code,
                'name' => $expedition->name,
            ],
            'services' => $services,
            'hub_changed' => $syncResult['hub_changed'] ?? false,
            'stock_warnings' => $syncResult['stock_warnings'] ?? [],
            'warehouse' => $sourceWarehouse ? [
                'id' => $sourceWarehouse->id,
                'name' => $sourceWarehouse->name,
                'location' => $sourceWarehouse->full_location,
            ] : null,
        ];

        Log::debug('[checkout.expedition-services] response', [
            'services_count' => count($services),
            'services' => $services,
            'hub_changed' => $responsePayload['hub_changed'],
            'stock_warnings' => $responsePayload['stock_warnings'],
        ]);

        // Removed dummy services fallback to ensure API data is the only source

        return response()->json($responsePayload);
    }

    public function checkStock(Request $request)
    {
        $address = Address::find($request->address_id);
        if (!$address) {
            return response()->json(['error' => 'Alamat tidak ditemukan'], 400);
        }

        $syncResult = $this->syncWarehouseByAddress($address);

        return response()->json([
            'stock_warnings' => $syncResult['stock_warnings'] ?? [],
            'hub_changed' => $syncResult['hub_changed'] ?? false,
        ]);
    }

    // Hardcoded logic removed in favor of RajaOngkirService

    public function store(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        Log::info('--- CHECKOUT STORE START ---', [
            'user_id' => Auth::id(),
            'payment_method' => $request->payment_method,
            'expedition_id' => $request->expedition_id,
            'expedition_service' => $request->expedition_service,
            'cart_ids' => $request->cart_ids,
        ]);

        $user = Auth::user();
        $allowedPayments = [
            'faspay', 'manual_transfer', 'faspay_qris', 'faspay_direct_debit', 
            'faspay_permata_va', 'faspay_mandiri_va', 'faspay_bri_va', 'faspay_cimb_va', 'faspay_bni_va',
            'faspay_sinarmas_va', 'faspay_maybank_va', 'faspay_danamon_va', 'faspay_bsi_va', 'faspay_bca_va'
        ];
        if ($user->isDistributor() && (int) ($user->term_of_payment ?? 0) > 0) {
            $allowedPayments[] = 'term_of_payment';
        }

        $request->validate([
            'address_id' => 'required|exists:addresses,id',
            'expedition_id' => 'required|exists:expeditions,id',
            'expedition_service' => 'required|string',
            'payment_method' => ['required', 'string', Rule::in($allowedPayments)],
            'sales_code' => ['nullable', 'string', 'max:255'],
        ]);

        // Verify address belongs to user
        $address = Address::where('id', $request->address_id)
            ->where('user_id', Auth::id())
            ->with(['wilayah'])
            ->first();

        if (!$address) {
            return back()->with('error', 'Alamat tidak valid.');
        }

        // Final sync of hub before order
        $this->syncWarehouseByAddress($address);

        $expedition = $this->findAvailableExpedition($request->expedition_id);
        if (!$expedition) {
            return back()->with('error', 'Ekspedisi tidak valid atau sudah tidak tersedia.');
        }

        $query = Cart::with(['product', 'warehouse.wilayah'])
            ->where('user_id', Auth::id())
            ->where('cart_type', 'regular');

        if ($request->has('cart_ids') && is_array($request->cart_ids)) {
            $query->whereIn('id', $request->cart_ids);
        }

        $carts = $query->get();

        if ($carts->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Keranjang kosong.');
        }

        // Get source warehouse from cart
        $sourceWarehouse = $carts->first()->warehouse;
        
        if (!$sourceWarehouse) {
            return back()->with('error', 'Hub pengirim tidak ditemukan.');
        }

        // Verify all items are from same warehouse
        $differentWarehouse = $carts->first(function ($cart) use ($sourceWarehouse) {
            return $cart->warehouse_id !== $sourceWarehouse->id;
        });
        
        if ($differentWarehouse) {
            return back()->with('error', 'Keranjang memiliki produk dari hub yang berbeda.');
        }

        // Check stock availability
        if (! ShopFulfillment::assumeStockReady()) {
            $stockErrors = [];
            
            $usesJubelio = is_array($sourceWarehouse->sync_sources) && in_array('jubelio', $sourceWarehouse->sync_sources);
            $jubelioItems = null;

            if ($usesJubelio && $sourceWarehouse->kode_hub) {
                try {
                    $jubelio = app(\App\Services\JubelioService::class);
                    $token = $jubelio->token();
                    $locationId = $jubelio->findLocationIdByCode($token, $sourceWarehouse->kode_hub);
                    if ($locationId) {
                        $jubelioItems = collect($jubelio->fetchItemsToSell($token, $locationId));
                    }
                } catch (\Exception $e) {
                    \Illuminate\Support\Facades\Log::warning('Checkout stock validation fallback to local', ['error' => $e->getMessage()]);
                }
            }

            foreach ($carts as $cart) {
                $productName = $cart->product->display_name;
                $qty = $cart->quantity;
                $productCode = $cart->product->code;

                if ($usesJubelio && $jubelioItems !== null) {
                    $needle = strtoupper(trim((string) $productCode));
                    $jItem = $jubelioItems->first(function ($item) use ($needle) {
                        return strtoupper(trim((string) ($item['item_code'] ?? ''))) === $needle;
                    });

                    if (!$jItem) {
                        $stockErrors[] = "{$productName}: Produk tidak tersedia/belum di-assign di gudang Jubelio.";
                        continue;
                    }

                    $availableStock = (int) ($jItem['available_qty'] ?? 0);
                    if ($qty > $availableStock) {
                        $stockErrors[] = "{$productName}: Dipesan {$qty}, tersedia {$availableStock} (Jubelio).";
                    }
                } else {
                    $stock = WarehouseStock::where('warehouse_id', $sourceWarehouse->id)
                        ->where('product_id', $cart->product_id)
                        ->first();

                    $availableStock = $stock ? $stock->stock : 0;

                    if ($qty > $availableStock) {
                        $stockErrors[] = "{$productName}: Dipesan {$qty}, tersedia {$availableStock}.";
                    }
                }
            }

            if (! empty($stockErrors)) {
                return back()->with('error', 'Stock tidak mencukupi di hub ' . $sourceWarehouse->name . ":\n" . implode("\n", $stockErrors));
            }
        }

        DB::beginTransaction();
        try {
            $orderNumber = $this->generateOrderNumber();
            $user->loadMissing('priceLevel');
            $pricing = $this->cartPricingBreakdown($user, $carts);
            $subtotal = $pricing['subtotal_after_distributor'];

            $totalWeight = $carts->sum(function ($cart) {
                return ($cart->product->weight ?? 500) * $cart->quantity;
            });

            $shippingCost = 0;
            \Log::info('Store: calculating shipping cost', [
                'origin' => $sourceWarehouse->district_id,
                'destination' => $address->district_id,
                'weight' => $totalWeight,
                'courier_code' => $expedition->code,
                'service_requested' => $request->expedition_service
            ]);
            $costResult = $this->resolveShippingCost(
                $expedition,
                $sourceWarehouse,
                $address,
                $totalWeight
            );

            $shippingCost = -1;
            $availableServices = [];
            if ($costResult && isset($costResult['data']) && !empty($costResult['data'])) {
                foreach ($costResult['data'] as $service) {
                    if (($service['code'] ?? '') === $expedition->code) {
                        $availableServices[] = $service['service'];
                        if (($service['service'] ?? '') === $request->expedition_service) {
                            $originalShippingCost = (float) $service['cost'];
                            $shippingCost = $originalShippingCost;
                            if ($expedition->code === 'jne') {
                                $shippingCost = $originalShippingCost * 0.8;
                            }
                        }
                    }
                }
            }

            // Auto-resolve if service mismatch happens on self_pickup or single available service
            if ($shippingCost < 0 && !empty($availableServices)) {
                if (in_array($expedition->code, ['self_pickup', 'kurir_toko']) || count($availableServices) === 1) {
                    $autoService = $availableServices[0];
                    \Log::info("Store: Auto-resolving expedition service mismatch for {$expedition->code} (requested: {$request->expedition_service}). Using service: {$autoService}");
                    $request->merge(['expedition_service' => $autoService]);
                    foreach ($costResult['data'] as $service) {
                        if (($service['code'] ?? '') === $expedition->code && ($service['service'] ?? '') === $autoService) {
                            $originalShippingCost = (float) $service['cost'];
                            $shippingCost = $originalShippingCost;
                            if ($expedition->code === 'jne') {
                                $shippingCost = $originalShippingCost * 0.8;
                            }
                            break;
                        }
                    }
                }
            }

            if ($shippingCost < 0) {
                \Log::error('Store: Gagal menghitung ongkos kirim.', [
                    'expedition' => $expedition->code,
                    'service_requested' => $request->expedition_service,
                    'available_services' => $availableServices,
                ]);

                DB::rollBack();

                $message = 'Gagal menghitung ongkos kirim. Silakan pilih ekspedisi dan layanan pengiriman kembali.';
                if ($availableServices !== []) {
                    $message .= ' Layanan tersedia untuk ' . $expedition->name . ': ' . implode(', ', $availableServices) . '.';
                }

                return back()->withInput()->with('error', $message);
            }
            
            // Calculate discount
            // Disable old DiscountTier logic as per new category-based discount rule
            $discountAmount = 0;
            $discountPercent = 0;

            $total = $subtotal - $discountAmount + $shippingCost;

            // Build full shipping address string for record
            $shippingAddressText = $address->recipient_name . "\n" .
                $address->phone . "\n" .
                $address->address_detail . "\n" .
                ($address->district_name ? 'Kec. ' . $address->district_name . ', ' : '') .
                ($address->regency_name ? $address->regency_name . ', ' : '') .
                ($address->province_name ?? '') .
                ($address->postal_code ? ' ' . $address->postal_code : '');

            // Calculate points for DRiiPPreneur based on product reseller_point
            $pointsEarned = 0;
            if ($user->isDriippreneurApproved()) {
                foreach ($carts as $cart) {
                    $pointsEarned += ($cart->product->reseller_point ?? 0) * $cart->quantity;
                }
            }

            // Track affiliate referral
            $affiliateId = session('affiliate_id');
            $affiliatePoints = 0;
            
            if ($affiliateId && $affiliateId !== Auth::id()) {
                $affiliateExists = User::where('id', $affiliateId)->exists();
                
                if ($affiliateExists) {
                    // Calculate 1 point per item purchased
                    $totalItems = $carts->sum('quantity');
                    $affiliatePoints = $totalItems;
                }
            }



            $orderNotes = $request->notes;
            if ($request->payment_method === 'term_of_payment' && $user->term_of_payment) {
                $totPrefix = 'TOT: pembayaran tempo ' . (int) $user->term_of_payment . ' hari.';
                $orderNotes = trim($totPrefix . (filled($orderNotes) ? ' | ' . $orderNotes : ''));
            }

            $orderType = $user->isDistributor() ? Order::TYPE_DISTRIBUTOR : Order::TYPE_REGULAR;

            $paymentFee = 0;
            if (str_starts_with($request->payment_method, 'faspay_')) {
                $paymentFee = (float) \App\Models\Setting::get('fee_' . $request->payment_method, 0);
                $total += $paymentFee;
            }

            $qadLocationCode = $sourceWarehouse->qad_location_code ?? $sourceWarehouse->kode_hub;
            $qadBatches = [];
            
            if ($qadLocationCode) {
                try {
                    $qad = app(\App\Services\QadService::class);
                    $response = $qad->getAllInventory([
                        'location' => $qadLocationCode,
                        'search' => '',
                        'batch' => '',
                        'length' => 1000,
                    ]);
                    
                    $items = class_exists(\App\Support\QadResponseHelper::class) 
                        ? \App\Support\QadResponseHelper::list($response) 
                        : ($response['data'] ?? []);
                    
                    $minBulan = $user->aturan_minimal_masa_berlaku ?? 0;
                    $minDate = \Carbon\Carbon::now()->addMonths($minBulan);

                    foreach ($items as $item) {
                        $itemCode = $item['item_code'] ?? $item['itemCode'] ?? $item['itemID'] ?? $item['itemid'] ?? null;
                        $qty = (int) ($item['qty'] ?? $item['quantity'] ?? $item['onHand'] ?? 0);
                        
                        $expiredStr = $item['expired_short'] ?? $item['expired'] ?? null;
                        $lotSerial = $item['lot_serial'] ?? $item['lotSerial'] ?? $item['batch'] ?? $item['lot'] ?? null;
                        $isValid = true;
                        
                        if ($lotSerial && strpos($lotSerial, '-') !== false) {
                            $isValid = false;
                        }
                        
                        if ($minBulan > 0 && $expiredStr) {
                            try {
                                $expDate = \Carbon\Carbon::parse($expiredStr);
                                if ($expDate->lt($minDate)) {
                                    $isValid = false;
                                }
                            } catch (\Exception $e) {
                                $isValid = false;
                            }
                        }

                        if ($isValid && $itemCode && $qty > 0) {
                            if (!isset($qadBatches[$itemCode])) {
                                $qadBatches[$itemCode] = [];
                            }
                            $qadBatches[$itemCode][] = [
                                'lot_serial' => $item['lot_serial'] ?? null,
                                'qty' => $qty,
                                'expired' => $expiredStr,
                            ];
                        }
                    }
                    
                    foreach ($qadBatches as $code => &$batches) {
                        usort($batches, function($a, $b) {
                            $timeA = strtotime($a['expired'] ?? '2099-12-31');
                            $timeB = strtotime($b['expired'] ?? '2099-12-31');
                            return $timeA <=> $timeB;
                        });
                    }
                } catch (\Exception $e) {
                    \Illuminate\Support\Facades\Log::error('QAD batch fetch failed at checkout: ' . $e->getMessage());
                }
            }

            $order = Order::create([
                'order_type' => $orderType, // Determine by role
                'order_number' => $orderNumber,
                'qid_sales_order_number' => $orderNumber,
                'user_id' => Auth::id(),
                'address_id' => $address->id,
                'expedition_id' => $expedition->id,
                'expedition_service' => $request->expedition_service,
                'source_warehouse_id' => $sourceWarehouse->id,
                'source_qad_location_code' => $qadLocationCode,
                'subtotal' => $subtotal,
                'discount_percent' => $discountPercent,
                'discount_amount' => $discountAmount,
                'shipping_cost' => $shippingCost,
                'payment_fee' => $paymentFee,
                'total_amount' => $total,
                'shipping_address' => $shippingAddressText,
                'payment_method' => $request->payment_method,
                'company' => $user->getFaspayCompany(),
                'payment_status' => 'pending',
                'order_status' => 'pending',
                'notes' => $orderNotes,
                'points_earned' => $pointsEarned,
                'points_credited' => false,
                'affiliate_id' => $affiliateId,
                'affiliate_points' => $affiliatePoints,
                'sales_code' => $request->sales_code,
            ]);
            
            Log::info('--- CHECKOUT DEBUG: ORDER CREATED ---', [
                'order_id' => $order->id,
                'order_number' => $order->order_number,
                'total_amount' => $total,
                'payment_method' => $request->payment_method,
                'company' => $order->company,
                'expedition_service' => $request->expedition_service,
            ]);

            // Load relationships for notification
            $order->load('address');

            $discountService = new \App\Services\DiscountService();

            foreach ($carts as $cart) {
                $lineUnit = $user->getProductPrice($cart->product);

                $allocatedBatches = [];
                $productCode = $cart->product->code;
                $qtyNeeded = $cart->quantity;
                
                if (isset($qadBatches[$productCode])) {
                    foreach ($qadBatches[$productCode] as &$batch) {
                        if ($qtyNeeded <= 0) break;
                        
                        if ($batch['qty'] > 0) {
                            $take = min($qtyNeeded, $batch['qty']);
                            $allocatedBatches[] = [
                                'lot_serial' => $batch['lot_serial'],
                                'qty' => $take,
                                'expired' => $batch['expired']
                            ];
                            $batch['qty'] -= $take;
                            $qtyNeeded -= $take;
                        }
                    }
                }

                $orderUom = $cart->showsLargeUnitInCart() ? 'large' : $cart->order_uom;
                $quantityOrdered = $cart->showsLargeUnitInCart() ? $cart->cartQuantityInputValue() : $cart->quantity_ordered;

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $cart->product_id,
                    'quantity' => $cart->quantity,
                    'order_uom' => $orderUom,
                    'quantity_ordered' => $quantityOrdered,
                    'price' => $lineUnit,
                    'subtotal' => $lineUnit * $cart->quantity,
                    'allocated_batches' => !empty($allocatedBatches) ? $allocatedBatches : null,
                ]);

                // Stok lokal tidak dikurangi — asumsi ready; fulfillment via Jubelio/QAD
                if (! ShopFulfillment::assumeStockReady()) {
                    $stock = WarehouseStock::where('warehouse_id', $sourceWarehouse->id)
                        ->where('product_id', $cart->product_id)
                        ->first();

                    if ($stock) {
                        $stock->decrement('stock', $cart->quantity);
                    }
                }
            }

            $deleteQuery = Cart::where('user_id', Auth::id())->where('cart_type', 'regular');
            if ($request->has('cart_ids') && is_array($request->cart_ids)) {
                $deleteQuery->whereIn('id', $request->cart_ids);
            }
            $deletedCartCount = $deleteQuery->delete();

            // Handle Faspay payment (to get invoice URL)
            $faspayInvoiceUrl = null;
            
            Log::info('--- CHECKOUT DEBUG ---', [
                'order_id' => $order->id,
                'order_number' => $order->order_number,
                'request_payment_method' => $request->payment_method,
                'deleted_cart_count' => $deletedCartCount,
                'config_active_gateway' => config('services.active_payment_gateway')
            ]);

            if ($request->payment_method === 'term_of_payment') {
                // TOT/TOP: tidak membuat invoice Faspay; pesanan menunggu pembayaran sesuai tempo
                Log::info('Checkout Debug: TOP selected, skipping gateway.');
                
                if (!empty($order->auto_approved_at_creation)) {
                    Log::info('Checkout Debug: TOP order auto approved, triggering hub notification and sync jobs.', ['order_id' => $order->id]);
                    $order->notifyHubAfterFinanceApproval();
                }
            } elseif (str_starts_with($request->payment_method, 'faspay')) {
                $activeGateway = config('services.active_payment_gateway');
                
                Log::info('Checkout Debug: Entering Gateway block.', [
                    'active_gateway' => $activeGateway,
                    'method' => $request->payment_method,
                    'company' => $order->company
                ]);

                if (str_starts_with($request->payment_method, 'faspay_')) {
                    $orderCompany = $order->company ?: \App\Services\FaspayConfig::getDefaultCompany();

                    // Faspay SNAP Flow (Direct UI)
                    if ($request->payment_method === 'faspay_qris') {
                        $snapService = new \App\Services\FaspaySnapService($orderCompany);
                        $qrisData = $snapService->generateQris($order, $total);
                        if ($qrisData && (isset($qrisData['qrUrl']) || isset($qrisData['additionalInfo']['qrImageUrl']))) {
                            $order->virtual_account_no = $qrisData['qrUrl'] ?? $qrisData['additionalInfo']['qrImageUrl'];
                            $order->payment_method = 'faspay_qris';
                            $order->save();
                            Log::info('Faspay QRIS generated successfully', ['order_id' => $order->id, 'company' => $orderCompany]);
                        } else {
                            Log::error('Failed to generate Faspay QRIS', ['order_id' => $order->id, 'company' => $orderCompany]);
                        }
                    } elseif ($request->payment_method === 'faspay_direct_debit') {
                        $snapService = new \App\Services\FaspaySnapService($orderCompany);
                        $debitData = $snapService->directDebitPayment($order, $total, '812');
                        if ($debitData && isset($debitData['responseCode']) && $debitData['responseCode'] === '2005400') {
                            $order->payment_method = 'faspay_direct_debit';
                            $order->faspay_redirect_url = $debitData['webRedirectUrl'] ?? $debitData['redirectUrl'] ?? null;
                            $order->save();
                            $faspayInvoiceUrl = $order->faspay_redirect_url;
                            Log::info('Faspay Direct Debit generated successfully', ['order_id' => $order->id, 'url' => $faspayInvoiceUrl, 'company' => $orderCompany]);
                        } else {
                            Log::error('Failed to generate Faspay Direct Debit', ['order_id' => $order->id, 'company' => $orderCompany]);
                        }
                    } elseif ($request->payment_method === 'faspay_bca_va') {
                        // BCA VA uses Legacy API
                        $faspayService = new \App\Services\FaspayService($orderCompany);
                        $invoice = $faspayService->createBill($order, $user, '702');
                        if ($invoice && isset($invoice['bill_no'])) {
                            $order->faspay_bill_no = $invoice['bill_no'] ?? $order->order_number;
                            $order->faspay_redirect_url = $invoice['redirect_url'];
                            $order->payment_method = 'faspay_bca_va';
                            if (empty($order->virtual_account_no)) {
                                // Generate a mock VA number for BCA so it displays on the frontend
                                $order->virtual_account_no = '0712' . substr(preg_replace('/[^0-9]/', '', $order->order_number), -11);
                            }
                            $order->save();
                            $faspayInvoiceUrl = $order->faspay_redirect_url;
                            
                            Log::info('Faspay BCA VA Invoice created', ['order_id' => $order->id, 'bill_no' => $order->faspay_bill_no, 'company' => $orderCompany]);
                        } else {
                            Log::error('Failed to generate Faspay BCA VA', ['order_id' => $order->id, 'company' => $orderCompany]);
                        }
                    } else {
                        // VA Static Flow using FaspayConfig
                        $prefix = \App\Services\FaspayConfig::getVaPrefix($request->payment_method, $orderCompany);
                        $targetLength = 16;
                        $prefixLength = strlen($prefix);
                        $freeDigitsLength = $targetLength - $prefixLength;
                        
                        // Extract digits from order number (WS260729001 -> 260729001)
                        $numericOrder = preg_replace('/[^0-9]/', '', $order->order_number);
                        if (strlen($numericOrder) > $freeDigitsLength) {
                            $freeDigits = substr($numericOrder, -$freeDigitsLength);
                        } else {
                            $freeDigits = str_pad($numericOrder, $freeDigitsLength, '0', STR_PAD_LEFT);
                        }
                        
                        $vaNumber = $prefix . $freeDigits;
                        
                        $order->virtual_account_no = $vaNumber;
                        $order->payment_method = $request->payment_method;
                        $order->save();
                        
                        Log::info('Faspay Static VA generated', ['order_id' => $order->id, 'va' => $vaNumber, 'company' => $orderCompany]);
                    }
                } else {
                    $faspayService = new \App\Services\FaspayService();
                    
                    $invoice = $faspayService->createBill($order, $user);

                    if ($invoice && isset($invoice['redirect_url'])) {
                        // Update order with invoice information
                        $order->faspay_bill_no = $invoice['bill_no'] ?? $order->order_number;
                        $order->faspay_redirect_url = $invoice['redirect_url'];
                        $order->save();
                        
                        $faspayInvoiceUrl = $order->faspay_redirect_url;

                        // Log for debugging
                        Log::info('Faspay invoice saved to order', [
                            'order_id' => $order->id,
                            'bill_no' => $order->faspay_bill_no,
                            'redirect_url' => $order->faspay_redirect_url,
                            'virtual_account_no' => $order->virtual_account_no,
                        ]);
                    } else {
                        DB::rollBack();
                        Log::error('Failed to create Faspay invoice', ['order_id' => $order->id]);
                        return redirect()->back()->with('error', 'Gagal membuat invoice pembayaran. Silakan coba lagi atau pastikan kredensial Faspay valid.');
                    }
                }
            } 
            // QAD sync (customer + SO) should only run after payment is PAID/SETTLED.
            // For Faspay, this is handled by the webhook (and success-page backup).
            // This prevents creating QAD customers for users who haven't completed a purchase.

            DB::commit();
            Log::info('--- CHECKOUT DEBUG: DB COMMITTED SUCCESS ---', ['order_id' => $order->id]);

            // Load relationships for notification (after commit to ensure data is saved)
            if (!$order->relationLoaded('address') || !$order->relationLoaded('items') || !$order->relationLoaded('expedition')) {
                $order->refresh();
                $order->load([
                    'user',
                    'address.village',
                    'address.district',
                    'address.regency',
                    'address.province',
                    'items.product',
                    'expedition',
                    'sourceWarehouse',
                ]);
            } else {
                if ($order->address && (! $order->address->relationLoaded('village') || ! $order->address->relationLoaded('district') || ! $order->address->relationLoaded('regency') || ! $order->address->relationLoaded('province'))) {
                    $order->address->load(['village', 'district', 'regency', 'province']);
                }
                $order->loadMissing(['user', 'sourceWarehouse']);
            }
            Log::info('--- CHECKOUT DEBUG: RELATIONSHIPS LOADED SUCCESS ---', ['order_id' => $order->id]);

                // Dispatch background job to send payment notification
                try {
                    \App\Jobs\SendWhatsAppNotification::dispatch($order, 'payment');
                    
                    // TOP: notifikasi hub dikirim setelah finance approve (bukan saat checkout)
                    // Untuk selain term_of_payment, notifikasi gudang dikirim setelah pembayaran diterima
                } catch (\Exception $exNotification) {
                    Log::warning('Checkout Debug: Gagal dispatch WhatsApp notification (non-fatal)', [
                        'order_id' => $order->id,
                        'error' => $exNotification->getMessage(),
                    ]);
                }
            
            // Note: Thank you notification will be sent after payment is successful via Xendit webhook

            Log::info('Checkout Debug: Checking redirect URLs.', [
                'xenditInvoiceUrl' => $xenditInvoiceUrl ?? null,
                'faspayInvoiceUrl' => $faspayInvoiceUrl ?? null,
                'request_payment_method' => $request->payment_method
            ]);

            // Redirect based on generated invoice URL rather than request parameter 
            // (in case frontend sent outdated payment_method due to cached views)

            if (isset($faspayInvoiceUrl) && $faspayInvoiceUrl) {
                // Redirect to Faspay payment page
                Log::info('Checkout Debug: Redirecting to Faspay', ['url' => $faspayInvoiceUrl]);
                return redirect($faspayInvoiceUrl);
            }

            Log::info('Checkout Debug: No gateway URL found. Redirecting to success page.');
            return redirect()->route('checkout.success', $order)->with('success', 'Pesanan berhasil dibuat.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('--- CHECKOUT STORE ERROR ---', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'input' => $request->except(['_token'])
            ]);
            return back()->with('error', 'Terjadi kesalahan saat membuat pesanan: ' . $e->getMessage());
        }
    }

    public function success(Order $order)
    {
        $order->load([
            'user',
            'items.product',
            'address.district',
            'address.regency',
            'address.province',
            'expedition',
            'sourceWarehouse.province',
            'sourceWarehouse.regency',
            'sourceWarehouse.district',
        ]);

        Log::info('Checkout success page accessed', [
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'payment_status' => $order->payment_status,
            'payment_method' => $order->payment_method,
        ]);

        if ($order->payment_status === 'paid') {
            try {
                \App\Jobs\SyncOrderToJubelio::dispatchSync($order);
                \Illuminate\Support\Facades\Log::info('Synchronous Jubelio sync executed for paid order.', ['order_id' => $order->id]);
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::error('Synchronous Jubelio sync failed.', ['error' => $e->getMessage()]);
            }
        }

        // Verifikasi Xendit, sync customer/QAD SO, dan WA thank-you setelah response terkirim (tidak menahan loading halaman).
        ProcessCheckoutSuccessJob::dispatch((string) $order->id)->afterResponse();

        return view('checkout.success', compact('order'));
    }

    /**
     * Status pembayaran untuk halaman checkout/success (polling realtime).
     */
    public function successPaymentStatus(Order $order)
    {
        abort_unless($order->user_id === Auth::id(), 403);

        $order->refresh();

        return response()->json([
            'payment_status' => $order->payment_status,
            'order_status' => $order->order_status,
            'payment_method' => $order->payment_method,
            'payment_url' => $order->faspay_redirect_url,
        ]);
    }

    private function generateOrderNumber(): string
    {
        return QadWsOrderNumberGenerator::generate();
    }

    /**
     * @param  \Illuminate\Support\Collection<int, \App\Models\Cart>  $carts
     * @return array{
     *     retail_subtotal: float,
     *     distributor_price_discount: float,
     *     subtotal_after_distributor: float,
     *     price_level_name: ?string,
     *     show_distributor_pricing: bool
     * }
     */
    private function cartPricingBreakdown(User $user, $carts): array
    {
        $retailSubtotal = (float) $carts->sum(function ($cart) use ($user) {
            return $user->getProductPrice($cart->product) * (int) $cart->quantity;
        });

        $user->loadMissing(['priceLevel', 'categoryDiscounts']);

        $subtotalAfterDistributor = $retailSubtotal;
        $distributorPriceDiscount = 0.0;
        $priceLevelName = null;

        $discountService = new \App\Services\DiscountService();
        $tieredDiscountAmount = 0.0;
        $tieredDiscountDetails = [];

        if ($user->isDistributor()) {
            $priceLevelName = $user->priceLevel ? $user->priceLevel->name : 'Diskon Kategori / Distributor';
            
            // Subdistributor / Reseller also gets cart-level category discounts?
            // User requested to use cart level discount. We will calculate it here.
            $discountData = $discountService->calculateCartDiscount($carts, $user);
            $tieredDiscountAmount = $discountData['total_discount_amount'];
            $tieredDiscountDetails = $discountData['discount_details'];
            $subtotalAfterDistributor = $retailSubtotal - $tieredDiscountAmount;
            
            $distributorPriceDiscount = $tieredDiscountAmount; // Show as tiered discount instead? Or combine?
            
            if ($tieredDiscountAmount == 0) {
                $priceLevelName = null; // Don't show if there's no discount
            }
        } else if (!$user->isDistributor()) {
            // Apply grouped category tiered discount for non-distributors
            $discountData = $discountService->calculateCartDiscount($carts, $user);
            $tieredDiscountAmount = $discountData['total_discount_amount'];
            $tieredDiscountDetails = $discountData['discount_details'];
            $subtotalAfterDistributor = $retailSubtotal - $tieredDiscountAmount;
        }

        return [
            'retail_subtotal' => $retailSubtotal,
            'distributor_price_discount' => $distributorPriceDiscount,
            'tiered_discount_amount' => $tieredDiscountAmount,
            'tiered_discount_details' => $tieredDiscountDetails,
            'subtotal_after_distributor' => $subtotalAfterDistributor,
            'price_level_name' => $priceLevelName,
            'show_distributor_pricing' => $user->isDistributor()
                && $distributorPriceDiscount > 0,
            'show_tiered_discount' => $tieredDiscountAmount > 0,
        ];
    }

    private function syncWarehouseByAddress(Address $address): ?array
    {
        $carts = Cart::with(['product'])->where('user_id', Auth::id())->where('cart_type', 'regular')->get();
        if ($carts->isEmpty()) {
            return null;
        }
        
        $pricing = $this->cartPricingBreakdown(Auth::user(), $carts);
        $totalAmount = $pricing['retail_subtotal'];

        $currentWarehouseId = $carts->first()->warehouse_id;
        $excludeOwnHubId = Auth::user()?->distributorShoppingExcludedWarehouseId();
        $hubChanged = false;
        $bestHub = null;

        if (ShopFulfillment::autoHubByAddress()) {
            $bestHub = ShopFulfillment::resolveNearestHub($address, $excludeOwnHubId, $totalAmount);

            if ($bestHub && $bestHub->id !== $currentWarehouseId) {
                $hubChanged = true;
                Cart::where('user_id', Auth::id())
                    ->where('cart_type', 'regular')
                    ->update(['warehouse_id' => $bestHub->id]);

                session([
                    'selected_hub_id' => $bestHub->id,
                    'selected_hub_name' => $bestHub->name,
                    'selected_hub_slug' => $bestHub->slug,
                ]);
            }
        }

        $currentHub = $bestHub ?: Warehouse::find($currentWarehouseId);

        $stockWarnings = [];
        if ($currentHub) {
            // Fetch QAD stock real-time
            $qadStock = null;
            $qadLocationCode = $currentHub->qad_location_code ?? $currentHub->kode_hub;
            
            if ($qadLocationCode) {
                try {
                    $qad = app(\App\Services\QadService::class);
                    $response = $qad->getAllInventory([
                        'location' => $qadLocationCode,
                        'search' => '',
                        'batch' => '',
                        'length' => 1000,
                    ]);
                    
                    if (class_exists(\App\Support\QadResponseHelper::class)) {
                        $items = \App\Support\QadResponseHelper::list($response);
                    } else {
                        $items = $response['data'] ?? [];
                    }
                    
                    $minBulan = \Illuminate\Support\Facades\Auth::user()?->aturan_minimal_masa_berlaku ?? 0;
                    $minDate = \Carbon\Carbon::now()->addMonths($minBulan);

                    $qadStock = [];
                    foreach ($items as $item) {
                        $itemCode = $item['item_code'] ?? $item['itemCode'] ?? $item['itemID'] ?? $item['itemid'] ?? null;
                        $qty = (int) ($item['qty'] ?? $item['quantity'] ?? $item['onHand'] ?? 0);
                        $lotSerial = $item['lot_serial'] ?? $item['lotSerial'] ?? $item['batch'] ?? $item['lot'] ?? null;
                        
                        if ($lotSerial && strpos($lotSerial, '-') !== false) {
                            continue;
                        }
                        
                        $expiredStr = $item['expired_short'] ?? $item['expired'] ?? null;
                        if ($minBulan > 0 && $expiredStr) {
                            try {
                                $expDate = \Carbon\Carbon::parse($expiredStr);
                                if ($expDate->lt($minDate)) {
                                    continue;
                                }
                            } catch (\Exception $e) {
                                continue;
                            }
                        }

                        if ($itemCode) {
                            $qadStock[$itemCode] = ($qadStock[$itemCode] ?? 0) + $qty;
                        }
                    }
                } catch (\Exception $e) {
                    \Illuminate\Support\Facades\Log::error('QAD stock check failed at checkout: ' . $e->getMessage());
                }
            }

            foreach ($carts as $cart) {
                // Get stock for this product in current hub
                $dbStock = \App\Models\WarehouseStock::where('warehouse_id', $currentHub->id)
                    ->where('product_id', $cart->product_id)
                    ->sum('stock');
                    
                $productCode = $cart->product->code;
                
                // If QAD location is configured and we fetched it successfully, use minimum of both to be safe
                if ($qadLocationCode && $qadStock !== null && !empty($qadStock)) {
                    $actualQadStock = $qadStock[$productCode] ?? 0;
                    $finalStock = min($dbStock, $actualQadStock);
                } else {
                    $finalStock = $dbStock;
                }
                    
                if ($cart->quantity > $finalStock) {
                    $stockWarnings[] = [
                        'cart_id' => $cart->id,
                        'product_name' => $cart->product->name,
                        'requested_qty' => $cart->quantity,
                        'available_qty' => $finalStock
                    ];
                }
            }
        }

        return [
            'hub_changed' => $hubChanged,
            'warehouse' => $currentHub,
            'stock_warnings' => $stockWarnings,
        ];
    }

    /**
     * @return array{data: array<int, array<string, mixed>>}|null
     */
    private function resolveShippingCost(
        Expedition $expedition,
        Warehouse $sourceWarehouse,
        Address $address,
        float $totalWeightGrams
    ): ?array {
        if (in_array($expedition->code, ['self_pickup', 'kurir_toko'])) {
            $isKurirToko = $expedition->code === 'kurir_toko';
            

            return [
                'data' => [
                    [
                        'code' => $expedition->code,
                        'name' => $isKurirToko ? 'Kurir Toko' : 'Ambil Sendiri',
                        'service' => $isKurirToko ? 'Kurir Toko' : 'Ambil Sendiri',
                        'description' => $isKurirToko ? 'Pengiriman oleh Kurir Toko' : 'Pickup dari ' . ($sourceWarehouse?->name ?? 'Gudang Pusat'),
                        'cost' => 0,
                        'etd' => '-',
                    ]
                ]
            ];
        }

        $cacheKey = sprintf(
            'shipping_cost_%s_%s_%s_%s',
            $expedition->code,
            $sourceWarehouse->id,
            $address->id,
            $totalWeightGrams
        );

        return \Illuminate\Support\Facades\Cache::remember($cacheKey, now()->addMinutes(10), function () use ($expedition, $sourceWarehouse, $address, $totalWeightGrams) {
            return $this->ekspedisiku->calculateCost(
                $sourceWarehouse->district_id,
                $address->district_id,
                max(1, $totalWeightGrams / 1000),
                $expedition->code,
                [
                    'warehouse' => $sourceWarehouse,
                    'address' => $address,
                ]
            );
        });
    }

    private function formatEstimatedDelivery(?string $etd, string $expeditionCode): string
    {
        if ($etd !== null && $etd !== '') {
            return str_contains(strtolower($etd), 'hari') || str_contains(strtolower($etd), 'jam') ? $etd : $etd.' hari';
        }

        return $expeditionCode === 'lalamove' ? 'Hari yang sama' : '2-3 hari';
    }

    /**
     * Courier codes that are active in EkspedisiKu API (is_active=true).
     *
     * @return array<int, string>
     */
    private function activeApiCourierCodes(): array
    {
        $dbCodes = Expedition::where('is_active', true)
            ->pluck('code')
            ->filter()
            ->values()
            ->all();

        $courierRes = $this->ekspedisiku->getCouriers();
        if (! isset($courierRes['data']) || ! is_array($courierRes['data'])) {
            return $dbCodes;
        }

        $activeEkspedisiKuCodes = ['self_pickup', 'kurir_toko'];
        foreach ($courierRes['data'] as $courier) {
            if (($courier['is_active'] ?? false) === true && ! empty($courier['id'])) {
                $activeEkspedisiKuCodes[] = $courier['id'];
            }
        }

        return array_values(array_intersect($dbCodes, $activeEkspedisiKuCodes));
    }

    private function findAvailableExpedition(?string $expeditionId): ?Expedition
    {
        if (! $expeditionId) {
            return null;
        }

        return Expedition::whereIn('code', $this->activeApiCourierCodes())->find($expeditionId);
    }

    private function usesEkspedisiKuRates(string $code): bool
    {
        return true;
    }
}
