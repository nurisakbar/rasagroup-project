<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\VerifyEmailController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\WhatsAppVerificationController;
use Illuminate\Support\Facades\Route;

Route::get('sales/search', [RegisteredUserController::class, 'searchSales'])->name('sales.search');

Route::middleware('guest')->group(function () {
    Route::get('auth/google', [GoogleController::class, 'redirectToGoogle'])->name('google.login');
    Route::get('auth/google/callback', [GoogleController::class, 'handleGoogleCallback'])->name('google.callback');

    Route::get('register', [RegisteredUserController::class, 'create'])
        ->name('register');

    Route::post('register', [RegisteredUserController::class, 'store']);


    Route::get('login', [AuthenticatedSessionController::class, 'create'])
        ->name('login');

    Route::post('login', [AuthenticatedSessionController::class, 'store']);

    Route::get('login-email', [AuthenticatedSessionController::class, 'createByEmail'])
        ->name('login.email');

    Route::post('login-email', [AuthenticatedSessionController::class, 'storeByEmail'])
        ->name('login.email.store');

    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])
        ->name('password.request');

    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])
        ->name('password.email');

    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset');

    Route::post('reset-password', [NewPasswordController::class, 'store'])
        ->name('password.store');
        
    Route::get('resend-verification', [EmailVerificationNotificationController::class, 'showResendForm'])
        ->name('verification.resend_form');

    Route::post('resend-verification', [EmailVerificationNotificationController::class, 'storePublic'])
        ->middleware('throttle:6,1')
        ->name('verification.resend_public');
});

Route::get('lbe', [AuthenticatedSessionController::class, 'createDistributorByEmail'])
    ->name('lbe');

Route::post('lbe', [AuthenticatedSessionController::class, 'storeDistributorByEmail'])
    ->name('lbe.store');

// Email verification link should work even for guest users (no session).
// The URL is protected by `signed` middleware + throttling.
Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
    ->middleware(['signed', 'throttle:6,1'])
    ->name('verification.verify');

Route::get('verified-success', function () {
    return view('auth.verified-success');
})->name('verification.success');

Route::middleware('auth')->group(function () {
    Route::get('verify-email', EmailVerificationPromptController::class)
        ->name('verification.notice');

    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware('throttle:6,1')
        ->name('verification.send');

    Route::get('confirm-password', [ConfirmablePasswordController::class, 'show'])
        ->name('password.confirm');

    Route::post('confirm-password', [ConfirmablePasswordController::class, 'store']);

    Route::put('password', [PasswordController::class, 'update'])->name('password.update');

    Route::post('logout', [AuthenticatedSessionController::class, 'destroy'])
        ->name('logout');

    // WhatsApp Verification
    Route::get('verify-wa', [WhatsAppVerificationController::class, 'show'])
        ->name('wa.verify');

    Route::get('verify-wa/success', [WhatsAppVerificationController::class, 'success'])
        ->name('wa.verify.success');

    Route::post('verify-wa', [WhatsAppVerificationController::class, 'verify'])
        ->name('wa.verify.post');

    Route::post('resend-wa', [WhatsAppVerificationController::class, 'resend'])
        ->name('wa.resend');

    Route::post('update-phone-wa', [WhatsAppVerificationController::class, 'updatePhone'])
        ->name('wa.update-phone');
});
