@extends('layouts.admin')

@section('title', 'Detail Hub — ' . $warehouse->name)
@section('page-title', $warehouse->name)
@section('page-description', 'Detail informasi dan stock hub')

@section('breadcrumb')
    <li><a href="{{ route('admin.warehouses.index') }}">Hub</a></li>
    <li class="active">{{ $warehouse->name }}</li>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="callout callout-info" style="margin-bottom: 15px;">
                <h4 style="margin-top: 0;">
                    <i class="fa fa-building"></i> {{ $warehouse->name }}
                    @if($warehouse->is_active)
                        <span class="label label-success">Aktif</span>
                    @else
                        <span class="label label-danger">Nonaktif</span>
                    @endif
                </h4>
                <p style="margin-bottom: 0;">
                    @if($warehouse->qad_location_code)
                        Lokasi WMS: <strong>{{ $warehouse->qad_location_code }}</strong>
                    @endif
                    @if($warehouse->full_location)
                        @if($warehouse->qad_location_code) &nbsp;|&nbsp; @endif
                        {{ $warehouse->full_location }}
                    @endif
                </p>
            </div>
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="{{ !request('tab') || request('tab') == 'info' ? 'active' : '' }}">
                        <a href="{{ route('admin.warehouses.show', [$warehouse, 'tab' => 'info']) }}"><i class="fa fa-info-circle"></i> Informasi Hub</a>
                    </li>
                    <li class="{{ request('tab') == 'stock' ? 'active' : '' }}">
                        <a href="{{ route('admin.warehouses.show', [$warehouse, 'tab' => 'stock']) }}"><i class="fa fa-cubes"></i> Informasi Stock</a>
                    </li>
                    <li class="{{ request('tab') == 'staff' ? 'active' : '' }}">
                        <a href="{{ route('admin.warehouses.show', [$warehouse, 'tab' => 'staff']) }}"><i class="fa fa-users"></i> Staff</a>
                    </li>
                    <li class="{{ request('tab') == 'operational_hours' ? 'active' : '' }}">
                        <a href="{{ route('admin.warehouses.show', [$warehouse, 'tab' => 'operational_hours']) }}"><i class="fa fa-clock-o"></i> Jadwal Operasional</a>
                    </li>
                    <li class="pull-right">
                        <a href="{{ route('admin.warehouses.index') }}" class="text-muted" style="padding: 10px 15px;"><i class="fa fa-arrow-left"></i> Kembali</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <!-- TAB 1: INFORMASI HUB -->
                    <div class="tab-pane {{ !request('tab') || request('tab') == 'info' ? 'active' : '' }}" id="tab_info">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="page-header">Detail Profil Hub</h4>
                                <table class="table table-bordered table-striped">
                                    <tr>
                                        <th width="30%">Nama Hub</th>
                                        <td><strong>{{ $warehouse->name }}</strong></td>
                                    </tr>
                                    @if($warehouse->kode_hub)
                                    <tr>
                                        <th>Kode Hub</th>
                                        <td><span class="badge bg-purple">{{ $warehouse->kode_hub }}</span></td>
                                    </tr>
                                    @endif
                                    <tr>
                                        <th>Lokasi</th>
                                        <td>{{ $warehouse->full_location }}</td>
                                    </tr>
                                    <tr>
                                        <th>Alamat Lengkap</th>
                                        <td>{{ $warehouse->address ?? '-' }}</td>
                                    </tr>
                                    <tr>
                                        <th>No. Telepon</th>
                                        <td>{{ $warehouse->phone ?? '-' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Status Operasional</th>
                                        <td>
                                            @if($warehouse->is_active)
                                                <span class="label label-success">Aktif</span>
                                            @else
                                                <span class="label label-danger">Nonaktif</span>
                                            @endif
                                        </td>
                                    </tr>
                                </table>
                                <div class="margin-top">
                                    <a href="{{ route('admin.warehouses.edit', $warehouse) }}" class="btn btn-warning">
                                        <i class="fa fa-edit"></i> Edit Informasi Hub
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h4 class="page-header">Statistik Ringkas</h4>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="small-box bg-aqua">
                                            <div class="inner">
                                                <h3>{{ $stocks->total() }}</h3>
                                                <p>Jenis Produk</p>
                                            </div>
                                            <div class="icon">
                                                <i class="fa fa-shopping-cart"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="small-box bg-green">
                                            <div class="inner">
                                                <h3>{{ number_format($warehouse->total_stock) }}</h3>
                                                <p>Total Unit Stock</p>
                                            </div>
                                            <div class="icon">
                                                <i class="fa fa-archive"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 2: INFORMASI STOCK -->
                    <div class="tab-pane {{ request('tab') == 'stock' ? 'active' : '' }}" id="tab_stock">
                        <div class="row" style="margin-bottom: 20px;">
                            <div class="col-md-8">
                                <form method="GET" action="{{ route('admin.warehouses.show', $warehouse) }}" class="form-horizontal">
                                    <input type="hidden" name="tab" value="stock">
                                    <div class="input-group">
                                        <input type="text" name="search" class="form-control" placeholder="Cari nama produk atau kode produk..." value="{{ request('search') }}">
                                        <span class="input-group-btn">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Cari</button>
                                            @if(request('search'))
                                                <a href="{{ route('admin.warehouses.show', $warehouse) }}?tab=stock" class="btn btn-default">Reset</a>
                                            @endif
                                        </span>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-4 text-right">
                                <form action="{{ route('admin.warehouses.sync-products', $warehouse) }}" method="POST" style="display: inline-block; margin-right: 5px;">
                                    @csrf
                                    <button type="submit" class="btn btn-success" onclick="return confirm('Tambahkan semua produk aktif (yang belum ada) ke hub ini dengan stok 0?')">
                                        <i class="fa fa-plus-circle"></i> Sinkron Produk
                                    </button>
                                </form>
                                <button type="button" class="btn btn-primary" id="btnSyncWms" @if(empty($wmsLocationCode)) disabled title="Lokasi WMS belum diisi" @endif>
                                    <i class="fa fa-refresh"></i> Sinkronisasi WMS
                                </button>
                                @if(!empty($wmsLastSyncAt))
                                    <div class="text-muted" style="margin-top: 6px; font-size: 12px;">
                                        Terakhir ditarik: {{ \Carbon\Carbon::parse($wmsLastSyncAt)->timezone('Asia/Jakarta')->format('d M Y H:i') }} WIB
                                    </div>
                                @endif
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="bg-gray">
                                    <tr>
                                        <th width="60" class="text-center">Gambar</th>
                                        <th>Produk</th>
                                        <th>Kode Produk</th>
                                        <th>Harga</th>
                                        <th width="120" class="text-center">Stok (Jubelio)</th>
                                        <th width="120" class="text-center">Fisik (WMS)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($stocks as $stock)
                                        @if(!$stock->product)
                                            @continue
                                        @endif
                                        <tr>
                                            <td class="text-center">
                                                @if($stock->product->image)
                                                    <img src="{{ asset($stock->product->image_url) }}" alt="Img" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px;" onerror="this.src='{{ asset('img/no-image.png') }}'; this.onerror=null;">
                                                @else
                                                    <div style="width: 40px; height: 40px; background: #eee; border-radius: 4px; display: flex; align-items: center; justify-content: center;">
                                                        <i class="fa fa-image text-muted"></i>
                                                    </div>
                                                @endif
                                            </td>
                                            <td>
                                                <strong>{{ $stock->product->name }}</strong>
                                                @if($stock->product->status !== 'active')
                                                    <span class="label label-warning">Nonaktif</span>
                                                @endif
                                                
                                                @if(isset($wmsBatches[$stock->product->code]) && count($wmsBatches[$stock->product->code]) > 0)
                                                    <div style="margin-top: 5px;">
                                                        @foreach($wmsBatches[$stock->product->code] as $batch)
                                                            <div>
                                                                <em>Batch : {{ $batch['lot_serial'] }} 
                                                                @if(!empty($batch['expired']))
                                                                    - Expired : {{ $batch['expired'] }}
                                                                @endif
                                                                </em> 
                                                                - Jumlah : {{ number_format($batch['qty']) }}
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                @endif
                                            </td>
                                            <td><code>{{ $stock->product->code }}</code></td>
                                            <td>Rp {{ number_format($stock->product->price, 0, ',', '.') }}</td>
                                            <td class="text-center">
                                                @if($stock->stock <= 10)
                                                    <span class="badge bg-red" style="font-size: 14px; padding: 5px 10px;" title="Stok Jubelio (Database)">{{ number_format($stock->stock) }}</span>
                                                @elseif($stock->stock <= 50)
                                                    <span class="badge bg-yellow" style="font-size: 14px; padding: 5px 10px;" title="Stok Jubelio (Database)">{{ number_format($stock->stock) }}</span>
                                                @else
                                                    <span class="badge bg-green" style="font-size: 14px; padding: 5px 10px;" title="Stok Jubelio (Database)">{{ number_format($stock->stock) }}</span>
                                                @endif
                                            </td>
                                            <td class="text-center">
                                                @php
                                                    $wmsTotal = 0;
                                                    if(isset($wmsBatches[$stock->product->code])) {
                                                        foreach($wmsBatches[$stock->product->code] as $b) {
                                                            $wmsTotal += $b['qty'];
                                                        }
                                                    }
                                                @endphp
                                                @if($wmsTotal > 0)
                                                    <span class="badge bg-purple" style="font-size: 14px; padding: 5px 10px;" title="Total dari WMS API">{{ number_format($wmsTotal) }}</span>
                                                    @if($stock->stock != $wmsTotal)
                                                        <br><small class="text-danger"><i class="fa fa-warning"></i> Selisih</small>
                                                    @endif
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="7" class="text-center">
                                                <div style="padding: 40px;">
                                                    <i class="fa fa-search fa-3x text-muted"></i>
                                                    <p class="text-muted mt-3">Tidak ada data stok yang ditemukan.</p>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <div class="row">
                            <div class="col-sm-5">
                                <div class="dataTables_info" style="padding-top: 10px;">
                                    Menampilkan {{ $stocks->firstItem() ?? 0 }} sampai {{ $stocks->lastItem() ?? 0 }} dari {{ $stocks->total() }} data
                                </div>
                            </div>
                            <div class="col-sm-7 text-right">
                                {{ $stocks->appends(request()->query())->links('pagination::simple-bootstrap-3') }}
                            </div>
                        </div>
                    </div>

                    <!-- TAB 3: STAFF -->
                    <div class="tab-pane {{ request('tab') == 'staff' ? 'active' : '' }}" id="tab_staff">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right" style="margin-bottom: 15px;">
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addUserModal">
                                        <i class="fa fa-user-plus"></i> Tambah Staff Baru
                                    </button>
                                </div>
                                
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr class="bg-gray">
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>No. Telepon</th>
                                            <th>Role</th>
                                            <th width="100" class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($warehouse->users as $user)
                                            <tr>
                                                <td><strong>{{ $user->name }}</strong></td>
                                                <td>{{ $user->email }}</td>
                                                <td>{{ $user->phone ?? '-' }}</td>
                                                <td>
                                                    @if($user->sub_role === 'admin')
                                                        <span class="label label-primary">Admin Hub</span>
                                                    @else
                                                        <span class="label label-default">Staff Hub</span>
                                                    @endif
                                                </td>
                                                <td class="text-center">
                                                    <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#editUserModal-{{ $user->id }}" title="Edit Staff">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                    <form action="{{ route('admin.warehouses.remove-user', [$warehouse, $user]) }}" method="POST" onsubmit="return confirm('Hapus staff ini?')" style="display:inline-block;">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-danger btn-xs" title="Hapus Staff">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="5" class="text-center">Belum ada staff yang terdaftar di hub ini.</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 4: JADWAL OPERASIONAL -->
                    <div class="tab-pane {{ request('tab') == 'operational_hours' ? 'active' : '' }}" id="tab_operational_hours">
                        <div class="row">
                            <div class="col-md-12">
                                <h4 class="page-header">Jadwal Operasional Hub</h4>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr class="bg-gray">
                                                <th width="150">Hari</th>
                                                <th width="120">Status</th>
                                                <th>Jam Buka</th>
                                                <th>Jam Tutup</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($warehouse->operationalHours as $hour)
                                                <tr>
                                                    <td><strong>{{ $hour->day_name }}</strong></td>
                                                    <td>
                                                        @if($hour->is_open)
                                                            <span class="label label-success">Buka</span>
                                                        @else
                                                            <span class="label label-danger">Tutup</span>
                                                        @endif
                                                    </td>
                                                    <td>{{ $hour->is_open ? $hour->open_time->format('H:i') : '-' }}</td>
                                                    <td>{{ $hour->is_open ? $hour->close_time->format('H:i') : '-' }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="4" class="text-center">
                                                        <div class="p-5">
                                                            <p>Belum ada data jadwal operasional untuk hub ini.</p>
                                                            <form action="{{ route('admin.warehouses.operational-hours.generate', $warehouse) }}" method="POST" style="display: inline;">
                                                                @csrf
                                                                <button type="submit" class="btn btn-primary btn-sm">Generate Default (08:00 - 20:00)</button>
                                                            </form>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="{{ route('admin.warehouses.add-user', $warehouse) }}" method="POST">
                    @csrf
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><i class="fa fa-user-plus"></i> Tambah Staff Hub</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="password" name="password" minlength="8" required>
                                <span class="input-group-btn">
                                    <button class="btn btn-default toggle-password" type="button">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="sub_role">Level Akses <span class="text-danger">*</span></label>
                            <select class="form-control" id="sub_role" name="sub_role" required>
                                <option value="admin">Admin Hub</option>
                                <option value="staff">Staff Hub</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="phone">No. Telepon</label>
                            <input type="text" class="form-control" id="phone" name="phone">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-save"></i> Simpan Staff</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit User Modals -->
    @foreach($warehouse->users as $user)
    <div class="modal fade" id="editUserModal-{{ $user->id }}" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="{{ route('admin.warehouses.update-user', [$warehouse, $user]) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><i class="fa fa-edit"></i> Edit Staff Hub</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="edit_name_{{ $user->id }}">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="edit_name_{{ $user->id }}" name="name" value="{{ $user->name }}" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_email_{{ $user->id }}">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="edit_email_{{ $user->id }}" name="email" value="{{ $user->email }}" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_password_{{ $user->id }}">Password <small class="text-muted">(Kosongkan jika tidak ingin mengubah password)</small></label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="edit_password_{{ $user->id }}" name="password" minlength="8">
                                <span class="input-group-btn">
                                    <button class="btn btn-default toggle-password" type="button">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="edit_sub_role_{{ $user->id }}">Level Akses <span class="text-danger">*</span></label>
                            <select class="form-control" id="edit_sub_role_{{ $user->id }}" name="sub_role" required>
                                <option value="admin" {{ $user->sub_role == 'admin' ? 'selected' : '' }}>Admin Hub</option>
                                <option value="staff" {{ $user->sub_role == 'staff' ? 'selected' : '' }}>Staff Hub</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_phone_{{ $user->id }}">No. Telepon</label>
                            <input type="text" class="form-control" id="edit_phone_{{ $user->id }}" name="phone" value="{{ $user->phone }}">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-save"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endforeach

    <div class="modal fade" id="wmsSyncModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-sm" role="document" style="margin-top: 18%;">
            <div class="modal-content text-center">
                <div class="modal-body" style="padding: 28px 20px;">
                    <i class="fa fa-refresh fa-spin fa-3x text-primary"></i>
                    <h4 style="margin-top: 18px; font-weight: 600;">Menarik data dari WMS</h4>
                    <p class="text-muted" style="margin-bottom: 0;">Proses penarikan stock batch sedang berjalan. Mohon tunggu.</p>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
        $(document).ready(function() {
            $('#btnSyncWms').on('click', function() {
                var $btn = $(this);
                if ($btn.prop('disabled')) {
                    return;
                }
                $btn.prop('disabled', true);
                $('#wmsSyncModal').modal('show');

                $.ajax({
                    url: @json(route('admin.warehouses.sync-stock-wms', $warehouse)),
                    method: 'POST',
                    timeout: 180000,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        'Accept': 'application/json'
                    },
                    success: function() {
                        window.location.reload();
                    },
                    error: function(xhr) {
                        $('#wmsSyncModal').modal('hide');
                        $btn.prop('disabled', false);
                        var message = (xhr.responseJSON && xhr.responseJSON.message)
                            ? xhr.responseJSON.message
                            : 'Gagal menarik stock batch dari WMS.';
                        if (typeof swal === 'function') {
                            swal('Gagal', message, 'error');
                        } else {
                            alert(message);
                        }
                    }
                });
            });
        });
    </script>
    @endpush

    @push('scripts')
    <script>
        $(document).ready(function() {
            $('.toggle-password').click(function() {
                $(this).find('i').toggleClass('fa-eye fa-eye-slash');
                var input = $(this).closest('.input-group').find('input');
                if (input.attr('type') === 'password') {
                    input.attr('type', 'text');
                } else {
                    input.attr('type', 'password');
                }
            });
        });
    </script>
    @endpush
@endsection
